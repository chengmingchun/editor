# 快速开始指南

## 1. 环境准备

### 1.1 安装Python
确保已安装Python 3.8或更高版本：
```bash
python --version
```

### 1.2 安装依赖
```bash
pip install -r requirements.txt
```

依赖包：
- `requests>=2.31.0` - HTTP客户端
- `pydantic>=2.5.0` - 数据验证
- `python-dotenv>=1.0.0` - 环境变量管理

## 2. 配置设置

### 2.1 复制环境变量文件
```bash
copy .env.example .env
```

### 2.2 编辑.env文件
```env
API_BASE_URL=http://比赛服务器IP:8080
USER_ID=你的用户工号
API_TIMEOUT=30
```

**重要**: `USER_ID`必须是比赛平台注册的用户工号，否则用例执行会有冲突！

## 3. 运行程序

### 3.1 交互式模式（推荐）
```bash
python main.py
```

示例交互：
```
请输入您的需求: 海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤
```

### 3.2 单次查询模式
```bash
python main.py --single "海淀区整租，预算5k以内"
```

### 3.3 批量处理模式
```bash
python main.py --batch examples/queries.txt results.json
```

### 3.4 测试模式
```bash
python main.py --test
```

## 4. 测试用例

### 4.1 运行单元测试
```bash
python -m pytest tests/
```

### 4.2 测试查询示例
查看 `examples/queries.txt` 文件，包含10个测试查询。

## 5. 程序功能验证

### 5.1 验证导入
```bash
python test_simple.py
```

预期输出：
```
[OK] 模型导入成功
[OK] 解析器导入成功
...
[SUCCESS] 所有核心模块导入成功！
```

### 5.2 验证需求解析
程序支持解析以下类型的需求：

1. **价格预算**
   - "预算5k以内"
   - "3k到8k"
   - "不超过6k"

2. **区域要求**
   - "海淀区"
   - "朝阳或者通州"
   - "西城、东城"

3. **户型要求**
   - "整租"
   - "合租单间"
   - "两室一厅"

4. **通勤要求**
   - "近地铁"
   - "到西二旗30分钟通勤"
   - "地铁口附近"

5. **装修要求**
   - "精装修"
   - "豪华装修"
   - "简装即可"

6. **其他要求**
   - "朝南"
   - "安静"
   - "立即入住"

## 6. 比赛注意事项

### 6.1 数据重置
程序在每个session开始时自动调用数据重置接口：
```python
self.api_client.reset_house_data()
```

### 6.2 请求头设置
所有房源相关接口自动添加 `X-User-ID` 请求头。

### 6.3 性能优化
- API响应缓存60秒
- 并行搜索优化
- Token使用统计
- 智能分页处理

### 6.4 输出格式
程序提供三种输出格式：
1. **文本格式** - 人类可读
2. **JSON格式** - 机器可读
3. **API格式** - 标准化响应

## 7. 故障排除

### 7.1 导入错误
```
ModuleNotFoundError: No module named 'requests'
```
解决方案：运行 `pip install -r requirements.txt`

### 7.2 API连接错误
```
API request failed: Connection refused
```
解决方案：检查 `API_BASE_URL` 配置和网络连接

### 7.3 权限错误
```
400 Bad Request
```
解决方案：检查 `USER_ID` 配置是否正确

### 7.4 编码错误
```
UnicodeEncodeError
```
解决方案：在Windows上使用ASCII字符或设置正确的编码

## 8. 性能监控

程序自动统计：
- 总Token使用量
- API调用次数
- 执行时间
- Tokens/秒
- API调用/秒

查看统计信息：
```
python main.py --single "测试查询"
```

## 9. 扩展开发

### 9.1 添加新需求解析
编辑 `src/agents/rental_agent.py` 中的 `RequirementParser` 类。

### 9.2 修改评分算法
编辑 `src/agents/rental_agent.py` 中的 `HouseScorer` 类。

### 9.3 添加新接口
编辑 `src/services/api_client.py` 文件。

### 9.4 修改输出格式
编辑 `src/utils/formatter.py` 文件。

## 10. 联系方式

如有问题，请参考：
- 项目文档: README.md
- 接口文档: 比赛提供的接口文档
- 错误日志: 程序运行时的错误信息