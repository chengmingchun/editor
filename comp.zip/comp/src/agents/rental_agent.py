import re
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

from models import (
    UserRequirement,
    House,
    Recommendation,
    HouseType,
    Decoration,
    Orientation,
    NoiseLevel,
    ListingPlatform,
)
from services.api_client import APIClient


class RequirementParser:
    @staticmethod
    def parse_text(text: str) -> UserRequirement:
        requirement = UserRequirement()

        price_patterns = [
            r"(\d+)[kK]\s*以内",
            r"不超过\s*(\d+)[kK]",
            r"(\d+)[kK]\s*以下",
            r"预算\s*(\d+)[kK]",
            r"(\d+)\s*到\s*(\d+)[kK]",
            r"(\d+)-(\d+)[kK]",
        ]

        for pattern in price_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if isinstance(match, tuple) and len(match) == 2:
                    min_price = int(match[0]) * 1000
                    max_price = int(match[1]) * 1000
                    requirement.min_price = min_price
                    requirement.max_price = max_price
                else:
                    max_price = int(match) * 1000
                    requirement.max_price = max_price

        district_keywords = {
            "海淀": "海淀",
            "朝阳": "朝阳",
            "通州": "通州",
            "昌平": "昌平",
            "大兴": "大兴",
            "房山": "房山",
            "西城": "西城",
            "丰台": "丰台",
            "顺义": "顺义",
            "东城": "东城",
        }

        districts = []
        for keyword, district in district_keywords.items():
            if keyword in text:
                districts.append(district)
        if districts:
            requirement.districts = districts

        if "整租" in text:
            requirement.house_type = HouseType.ENTIRE
        elif "合租" in text or "单间" in text:
            requirement.house_type = HouseType.SHARED

        layout_patterns = [r"(\d+)室", r"(\d+)居", r"(\d+)房"]
        for pattern in layout_patterns:
            match = re.search(pattern, text)
            if match:
                rooms = match.group(1)
                requirement.layout = f"{rooms}室"
                break

        area_patterns = [r"(\d+)\s*平", r"面积\s*(\d+)", r"(\d+)\s*平米"]
        for pattern in area_patterns:
            match = re.search(pattern, text)
            if match:
                area = int(match.group(1))
                requirement.min_area = area * 0.8
                requirement.max_area = area * 1.2
                break

        subway_patterns = [r"近地铁", r"地铁附近", r"地铁口"]
        for pattern in subway_patterns:
            if re.search(pattern, text):
                requirement.max_subway_distance = 800
                break

        commute_patterns = [
            r"(\d+)\s*分钟.*通勤",
            r"通勤\s*(\d+)\s*分钟",
            r"到西二旗\s*(\d+)\s*分钟",
        ]
        for pattern in commute_patterns:
            match = re.search(pattern, text)
            if match:
                requirement.max_commute_time = int(match.group(1))
                break

        landmark_keywords = ["西二旗", "国贸", "望京", "中关村", "上地"]
        landmarks = []
        for keyword in landmark_keywords:
            if keyword in text:
                landmarks.append(keyword)
        if landmarks:
            requirement.target_landmarks = landmarks

        decoration_keywords = {
            "精装": Decoration.FINE,
            "豪华": Decoration.LUXURY,
            "简装": Decoration.SIMPLE,
            "毛坯": Decoration.ROUGH,
            "空房": Decoration.EMPTY,
        }
        for keyword, decoration in decoration_keywords.items():
            if keyword in text:
                requirement.decoration = decoration
                break

        orientation_keywords = {
            "朝南": Orientation.SOUTH,
            "南北": Orientation.SOUTH_NORTH,
            "朝北": Orientation.NORTH,
            "朝东": Orientation.EAST,
            "朝西": Orientation.WEST,
        }
        for keyword, orientation in orientation_keywords.items():
            if keyword in text:
                requirement.orientation = orientation
                break

        noise_keywords = {
            "安静": NoiseLevel.QUIET,
            "吵闹": NoiseLevel.NOISY,
            "临街": NoiseLevel.STREET,
        }
        for keyword, noise in noise_keywords.items():
            if keyword in text:
                requirement.noise_level = noise
                break

        date_patterns = [
            r"(\d+)月(\d+)日",
            r"(\d+)[/.-](\d+)",
            r"(\d+)\s*号",
            r"立即入住",
        ]
        for pattern in date_patterns:
            match = re.search(pattern, text)
            if match:
                if "立即入住" in text:
                    requirement.available_date = datetime.now().strftime("%Y-%m-%d")
                break

        return requirement


class HouseScorer:
    @staticmethod
    def calculate_score(
        house: House, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        score = 100.0
        reasons = []

        if requirement.max_price and house.price > requirement.max_price:
            score -= 30
            reasons.append(f"价格{house.price}元超出预算")
        elif requirement.min_price and house.price < requirement.min_price:
            score -= 10
            reasons.append(f"价格{house.price}元可能质量不佳")
        else:
            reasons.append(f"价格{house.price}元符合预算")

        if requirement.districts and house.district not in requirement.districts:
            score -= 25
            reasons.append(f"区域{house.district}不符合要求")
        else:
            reasons.append(f"位于{house.district}区")

        if requirement.house_type and house.house_type != requirement.house_type:
            score -= 20
            reasons.append(f"类型{house.house_type.value}不符合")
        else:
            reasons.append(f"类型{house.house_type.value}符合")

        if requirement.layout and requirement.layout not in house.layout:
            score -= 15
            reasons.append(f"户型{house.layout}不符合{requirement.layout}要求")
        else:
            reasons.append(f"户型{house.layout}合适")

        if requirement.min_area and house.area < requirement.min_area:
            score -= 10
            reasons.append(f"面积{house.area}㎡偏小")
        elif requirement.max_area and house.area > requirement.max_area:
            score -= 5
            reasons.append(f"面积{house.area}㎡偏大")
        else:
            reasons.append(f"面积{house.area}㎡适中")

        if (
            requirement.max_subway_distance
            and house.subway_distance > requirement.max_subway_distance
        ):
            penalty = min(
                20, (house.subway_distance - requirement.max_subway_distance) / 100
            )
            score -= penalty
            reasons.append(f"距地铁{house.subway_distance}米较远")
        else:
            reasons.append(f"距地铁{house.subway_distance}米方便")

        if (
            requirement.max_commute_time
            and house.xierqi_commute > requirement.max_commute_time
        ):
            penalty = min(25, (house.xierqi_commute - requirement.max_commute_time) / 5)
            score -= penalty
            reasons.append(f"西二旗通勤{house.xierqi_commute}分钟较长")
        else:
            reasons.append(f"西二旗通勤{house.xierqi_commute}分钟合理")

        if requirement.decoration and house.decoration != requirement.decoration:
            score -= 8
            reasons.append(f"装修{house.decoration.value}不符合要求")
        else:
            reasons.append(f"装修{house.decoration.value}良好")

        if requirement.orientation and house.orientation != requirement.orientation:
            score -= 5
            reasons.append(f"朝向{house.orientation.value}不符合")
        else:
            reasons.append(f"朝向{house.orientation.value}采光好")

        if requirement.noise_level and house.noise_level != requirement.noise_level:
            if requirement.noise_level == NoiseLevel.QUIET and house.noise_level in [
                NoiseLevel.NOISY,
                NoiseLevel.STREET,
            ]:
                score -= 12
                reasons.append(f"噪音{house.noise_level.value}不符合安静要求")
            else:
                score -= 5
                reasons.append(f"噪音{house.noise_level.value}可能不理想")
        else:
            reasons.append(f"噪音水平{house.noise_level.value}")

        positive_tags = ["近地铁", "精装修", "朝南", "有电梯", "高楼层", "采光好"]
        for tag in positive_tags:
            if tag in house.tags:
                score += 3
                reasons.append(f"具有{tag}优势")

        negative_tags = ["临街", "毛坯", "空房", "农村房"]
        for tag in negative_tags:
            if tag in house.tags:
                score -= 3
                reasons.append(f"存在{tag}劣势")

        score = max(0, min(100, score))

        return score, reasons


class RentalAgent:
    def __init__(self):
        self.api_client = APIClient()
        self.parser = RequirementParser()
        self.scorer = HouseScorer()

    def initialize_session(self):
        self.api_client.reset_house_data()

    def search_houses(self, requirement: UserRequirement) -> List[House]:
        all_houses = []

        if requirement.target_landmarks:
            for landmark_name in requirement.target_landmarks:
                landmark = self.api_client.get_landmark_by_name(landmark_name)
                if landmark:
                    result = self.api_client.get_houses_nearby(
                        landmark.id, max_distance=2000, page_size=50
                    )
                    all_houses.extend(result.houses)

        if requirement.districts:
            for district in requirement.districts:
                landmarks = self.api_client.get_landmarks(district=district)
                for landmark in landmarks[:3]:
                    result = self.api_client.get_houses_nearby(
                        landmark.id, max_distance=3000, page_size=30
                    )
                    all_houses.extend(result.houses)

        if not all_houses:
            result = self.api_client.get_houses_by_platform(page_size=100)
            all_houses = result.houses

        unique_houses = {}
        for house in all_houses:
            if house.id not in unique_houses and house.status.value == "可租":
                unique_houses[house.id] = house

        filtered_houses = []
        for house in unique_houses.values():
            if self._filter_house(house, requirement):
                filtered_houses.append(house)

        return filtered_houses

    def _filter_house(self, house: House, requirement: UserRequirement) -> bool:
        if requirement.max_price and house.price > requirement.max_price:
            return False

        if requirement.min_price and house.price < requirement.min_price:
            return False

        if requirement.districts and house.district not in requirement.districts:
            return False

        if requirement.house_type and house.house_type != requirement.house_type:
            return False

        if requirement.layout and requirement.layout not in house.layout:
            return False

        if requirement.min_area and house.area < requirement.min_area:
            return False

        if requirement.max_area and house.area > requirement.max_area:
            return False

        if (
            requirement.max_subway_distance
            and house.subway_distance > requirement.max_subway_distance
        ):
            return False

        if (
            requirement.max_commute_time
            and house.xierqi_commute > requirement.max_commute_time
        ):
            return False

        if requirement.decoration and house.decoration != requirement.decoration:
            return False

        if requirement.orientation and house.orientation != requirement.orientation:
            return False

        if requirement.min_bathrooms and house.bathrooms < requirement.min_bathrooms:
            return False

        if requirement.noise_level and house.noise_level != requirement.noise_level:
            if requirement.noise_level == "安静" and house.noise_level in [
                "吵闹",
                "临街",
            ]:
                return False

        return True

    def get_recommendations(
        self, houses: List[House], requirement: UserRequirement, top_n: int = 5
    ) -> List[Recommendation]:
        scored_houses = []

        for house in houses:
            score, reasons = self.scorer.calculate_score(house, requirement)
            listings = self.api_client.get_house_listings(house.id)

            listing_platforms = [listing.platform for listing in listings]
            if len(listing_platforms) >= 2:
                score += 5
                reasons.append("多平台验证，房源可信")
            elif len(listing_platforms) == 0:
                score -= 10
                reasons.append("无平台验证，需谨慎")

            scored_houses.append((score, house, reasons, listings))

        scored_houses.sort(key=lambda x: x[0], reverse=True)

        recommendations = []
        for score, house, reasons, listings in scored_houses[:top_n]:
            recommendation = Recommendation(
                house=house, score=score, reasons=reasons, listings=listings
            )
            recommendations.append(recommendation)

        return recommendations

    def process_query(self, query: str) -> Dict[str, Any]:
        self.initialize_session()

        requirement = self.parser.parse_text(query)

        houses = self.search_houses(requirement)

        recommendations = self.get_recommendations(houses, requirement)

        stats = self.api_client.get_house_stats()

        result = {
            "requirement": requirement.dict(exclude_none=True),
            "total_houses_found": len(houses),
            "recommendations": [rec.dict() for rec in recommendations],
            "stats": stats,
        }

        return result

    def rent_house(
        self, house_id: str, platform: ListingPlatform = ListingPlatform.ANJUKE
    ) -> bool:
        return self.api_client.rent_house(house_id, platform)
