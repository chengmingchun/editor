from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class LandmarkCategory(str, Enum):
    SUBWAY = "subway"
    COMPANY = "company"
    BUSINESS = "business"
    SUPERMARKET = "supermarket"
    PARK = "park"


class HouseType(str, Enum):
    ENTIRE = "entire"
    SHARED = "shared"


class Decoration(str, Enum):
    SIMPLE = "简装"
    FINE = "精装"
    LUXURY = "豪华"
    ROUGH = "毛坯"
    EMPTY = "空房"


class Orientation(str, Enum):
    SOUTH = "朝南"
    NORTH = "朝北"
    EAST = "朝东"
    WEST = "朝西"
    SOUTH_NORTH = "南北"
    EAST_WEST = "东西"


class NoiseLevel(str, Enum):
    QUIET = "安静"
    MEDIUM = "中等"
    NOISY = "吵闹"
    STREET = "临街"


class HouseStatus(str, Enum):
    AVAILABLE = "可租"
    RENTED = "已租"
    OFFLINE = "下架"


class ListingPlatform(str, Enum):
    ANJUKE = "安居客"
    LIANJIA = "链家"
    WUBA = "58同城"


class Landmark(BaseModel):
    id: str
    name: str
    category: LandmarkCategory
    district: str
    latitude: float
    longitude: float
    description: Optional[str] = None


class House(BaseModel):
    id: str
    address: str
    district: str
    community: str
    house_type: HouseType
    layout: str
    area: float
    price: int
    available_date: str
    floor: str
    subway_station: str
    subway_distance: int
    xierqi_commute: int
    decoration: Decoration
    orientation: Orientation
    bathrooms: int
    noise_level: NoiseLevel
    tags: List[str]
    status: HouseStatus
    latitude: float
    longitude: float


class HouseListing(BaseModel):
    platform: ListingPlatform
    house_id: str
    price: int
    status: HouseStatus
    posted_at: str


class UserRequirement(BaseModel):
    max_price: Optional[int] = None
    min_price: Optional[int] = None
    districts: Optional[List[str]] = None
    house_type: Optional[HouseType] = None
    layout: Optional[str] = None
    min_area: Optional[float] = None
    max_area: Optional[float] = None
    max_subway_distance: Optional[int] = None
    max_commute_time: Optional[int] = None
    target_landmarks: Optional[List[str]] = None
    decoration: Optional[Decoration] = None
    orientation: Optional[Orientation] = None
    min_bathrooms: Optional[int] = None
    noise_level: Optional[NoiseLevel] = None
    tags: Optional[List[str]] = None
    available_date: Optional[str] = None


class SearchResult(BaseModel):
    houses: List[House]
    total: int
    page: int
    page_size: int


class Recommendation(BaseModel):
    house: House
    score: float
    reasons: List[str]
    listings: List[HouseListing]
