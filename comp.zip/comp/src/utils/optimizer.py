import time
from typing import List, Dict, Any, Callable
from functools import wraps
from models import UserRequirement


class TokenOptimizer:
    def __init__(self):
        self.token_count = 0
        self.api_calls = 0
        self.start_time = time.time()

    def count_tokens(self, text: str) -> int:
        chinese_chars = sum(1 for char in text if "\u4e00" <= char <= "\u9fff")
        english_chars = sum(
            1 for char in text if char.isalpha() and not ("\u4e00" <= char <= "\u9fff")
        )
        digits = sum(1 for char in text if char.isdigit())
        spaces = sum(1 for char in text if char.isspace())
        other = len(text) - chinese_chars - english_chars - digits - spaces

        tokens = (
            chinese_chars * 1.5
            + english_chars * 0.25
            + digits * 0.25
            + spaces * 0.1
            + other * 0.5
        )
        return int(tokens)

    def track_api_call(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            self.api_calls += 1
            start = time.time()
            result = func(*args, **kwargs)
            duration = time.time() - start

            if isinstance(result, dict) and "data" in result:
                result_str = str(result["data"])
                self.token_count += self.count_tokens(result_str)
            elif isinstance(result, list):
                result_str = str(result[:10])
                self.token_count += self.count_tokens(result_str)
            elif isinstance(result, str):
                self.token_count += self.count_tokens(result)

            return result

        return wrapper

    def optimize_requirement(self, requirement: UserRequirement) -> UserRequirement:
        optimized = UserRequirement()

        if requirement.max_price and requirement.max_price > 25000:
            optimized.max_price = 25000

        if requirement.min_price and requirement.min_price < 500:
            optimized.min_price = 500

        if requirement.districts and len(requirement.districts) > 3:
            optimized.districts = requirement.districts[:3]
        else:
            optimized.districts = requirement.districts

        optimized.house_type = requirement.house_type

        if requirement.layout:
            optimized.layout = requirement.layout

        if requirement.min_area and requirement.min_area < 22:
            optimized.min_area = 22

        if requirement.max_area and requirement.max_area > 145:
            optimized.max_area = 145

        if requirement.max_subway_distance and requirement.max_subway_distance < 200:
            optimized.max_subway_distance = 200
        elif requirement.max_subway_distance and requirement.max_subway_distance > 5500:
            optimized.max_subway_distance = 5500
        else:
            optimized.max_subway_distance = requirement.max_subway_distance

        if requirement.max_commute_time and requirement.max_commute_time < 8:
            optimized.max_commute_time = 8
        elif requirement.max_commute_time and requirement.max_commute_time > 95:
            optimized.max_commute_time = 95
        else:
            optimized.max_commute_time = requirement.max_commute_time

        if requirement.target_landmarks and len(requirement.target_landmarks) > 2:
            optimized.target_landmarks = requirement.target_landmarks[:2]
        else:
            optimized.target_landmarks = requirement.target_landmarks

        optimized.decoration = requirement.decoration
        optimized.orientation = requirement.orientation

        if requirement.min_bathrooms and requirement.min_bathrooms > 2:
            optimized.min_bathrooms = 2
        else:
            optimized.min_bathrooms = requirement.min_bathrooms

        optimized.noise_level = requirement.noise_level

        if requirement.tags and len(requirement.tags) > 5:
            optimized.tags = requirement.tags[:5]
        else:
            optimized.tags = requirement.tags

        optimized.available_date = requirement.available_date

        return optimized

    def get_stats(self) -> Dict[str, Any]:
        duration = time.time() - self.start_time
        return {
            "total_tokens": self.token_count,
            "api_calls": self.api_calls,
            "duration_seconds": round(duration, 2),
            "tokens_per_second": round(self.token_count / max(duration, 0.1), 2),
            "api_calls_per_second": round(self.api_calls / max(duration, 0.1), 2),
        }

    def print_stats(self):
        stats = self.get_stats()
        print("\n" + "=" * 50)
        print("📊 性能统计:")
        print("=" * 50)
        print(f"总Token数: {stats['total_tokens']}")
        print(f"API调用次数: {stats['api_calls']}")
        print(f"执行时间: {stats['duration_seconds']}秒")
        print(f"Token/秒: {stats['tokens_per_second']}")
        print(f"API调用/秒: {stats['api_calls_per_second']}")
        print("=" * 50)


class CacheManager:
    def __init__(self, ttl: int = 300):
        self.cache = {}
        self.ttl = ttl

    def get(self, key: str):
        if key in self.cache:
            data, timestamp = self.cache[key]
            if time.time() - timestamp < self.ttl:
                return data
            else:
                del self.cache[key]
        return None

    def set(self, key: str, data: Any):
        self.cache[key] = (data, time.time())

    def clear(self):
        self.cache.clear()


class SearchOptimizer:
    @staticmethod
    def prioritize_search_strategies(requirement: UserRequirement) -> List[str]:
        strategies = []

        if requirement.target_landmarks:
            strategies.append("landmark_nearby")

        if requirement.districts:
            strategies.append("district_landmarks")

        if requirement.max_subway_distance and requirement.max_subway_distance <= 800:
            strategies.append("subway_proximity")

        if requirement.max_commute_time and requirement.max_commute_time <= 30:
            strategies.append("fast_commute")

        if not strategies:
            strategies.append("general_search")

        return strategies

    @staticmethod
    def estimate_result_count(requirement: UserRequirement) -> int:
        base_count = 1000

        if requirement.max_price:
            if requirement.max_price < 3000:
                base_count *= 0.3
            elif requirement.max_price < 8000:
                base_count *= 0.6
            else:
                base_count *= 0.8

        if requirement.districts:
            base_count *= 0.2 * len(requirement.districts)

        if requirement.house_type:
            base_count *= 0.5

        if requirement.max_subway_distance and requirement.max_subway_distance <= 800:
            base_count *= 0.3

        if requirement.max_commute_time and requirement.max_commute_time <= 30:
            base_count *= 0.2

        return max(10, min(1000, int(base_count)))
