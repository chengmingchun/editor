from typing import List, Dict, Any
from models import Recommendation, House


class OutputFormatter:
    @staticmethod
    def format_recommendation(rec: Recommendation, index: int) -> str:
        house = rec.house

        output = f"【推荐房源 #{index + 1}】\n"
        output += f"🏠 {house.community} - {house.layout} - {house.area}㎡\n"
        output += f"📍 地址: {house.address} ({house.district}区)\n"
        output += f"💰 租金: {house.price}元/月\n"
        output += f"🚇 地铁: {house.subway_station} ({house.subway_distance}米)\n"
        output += f"⏱️  西二旗通勤: {house.xierqi_commute}分钟\n"
        output += (
            f"🏗️  装修: {house.decoration.value} | 朝向: {house.orientation.value}\n"
        )
        output += f"🚽 卫生间: {house.bathrooms}个 | 噪音: {house.noise_level.value}\n"
        output += f"🏷️  标签: {', '.join(house.tags[:5])}\n"

        if rec.listings:
            platforms = [listing.platform.value for listing in rec.listings]
            output += f"📱 平台: {', '.join(platforms)}\n"

        output += f"📊 匹配度: {rec.score:.1f}/100\n"
        output += "📋 推荐理由:\n"
        for reason in rec.reasons[:8]:
            output += f"  • {reason}\n"

        output += "-" * 50 + "\n"
        return output

    @staticmethod
    def format_summary(result: Dict[str, Any]) -> str:
        output = "=" * 60 + "\n"
        output += "🏡 租房智能体 - 搜索结果汇总\n"
        output += "=" * 60 + "\n\n"

        req = result.get("requirement", {})
        if req:
            output += "📝 解析的需求:\n"
            for key, value in req.items():
                if value:
                    output += f"  • {key}: {value}\n"
            output += "\n"

        output += f"🔍 找到房源: {result.get('total_houses_found', 0)}套\n"
        output += f"⭐ 推荐房源: {len(result.get('recommendations', []))}套\n\n"

        recommendations = result.get("recommendations", [])
        if recommendations:
            output += "🏆 最佳推荐:\n"
            for i, rec_data in enumerate(recommendations[:3]):
                rec = Recommendation(**rec_data)
                house = rec.house
                output += f"  {i + 1}. {house.community} - {house.layout} - {house.price}元/月"
                output += f" (匹配度: {rec.score:.1f})\n"

        stats = result.get("stats", {})
        if stats:
            output += "\n📈 市场概况:\n"
            if "total_houses" in stats:
                output += f"  • 总房源数: {stats.get('total_houses', 0)}\n"
            if "available_houses" in stats:
                output += f"  • 可租房源: {stats.get('available_houses', 0)}\n"
            if "avg_price" in stats:
                output += f"  • 平均租金: {stats.get('avg_price', 0):.0f}元/月\n"

        output += "\n" + "=" * 60 + "\n"
        return output

    @staticmethod
    def format_quick_view(recommendations: List[Recommendation]) -> str:
        if not recommendations:
            return "未找到符合条件的房源"

        output = "🏠 快速预览 (前5名):\n"
        output += "排名 | 小区 | 户型 | 租金 | 地铁距离 | 通勤 | 匹配度\n"
        output += "-" * 70 + "\n"

        for i, rec in enumerate(recommendations[:5]):
            house = rec.house
            output += f"{i + 1:2d} | {house.community[:10]:10s} | {house.layout:4s} | "
            output += f"{house.price:6d}元 | {house.subway_distance:4d}m | "
            output += f"{house.xierqi_commute:3d}min | {rec.score:5.1f}\n"

        return output

    @staticmethod
    def format_for_api(result: Dict[str, Any]) -> Dict[str, Any]:
        api_result = {
            "success": True,
            "data": {
                "query_analysis": result.get("requirement", {}),
                "search_results": {
                    "total": result.get("total_houses_found", 0),
                    "recommended": len(result.get("recommendations", [])),
                    "recommendations": [],
                },
                "market_stats": result.get("stats", {}),
            },
        }

        for rec_data in result.get("recommendations", []):
            rec = Recommendation(**rec_data)
            house = rec.house

            recommendation = {
                "house_id": house.id,
                "community": house.community,
                "address": house.address,
                "district": house.district,
                "layout": house.layout,
                "area": house.area,
                "price": house.price,
                "subway_station": house.subway_station,
                "subway_distance": house.subway_distance,
                "xierqi_commute": house.xierqi_commute,
                "decoration": house.decoration.value,
                "orientation": house.orientation.value,
                "bathrooms": house.bathrooms,
                "noise_level": house.noise_level.value,
                "tags": house.tags,
                "match_score": rec.score,
                "reasons": rec.reasons,
                "platforms": [listing.platform.value for listing in rec.listings],
                "coordinates": {
                    "latitude": house.latitude,
                    "longitude": house.longitude,
                },
            }
            api_result["data"]["search_results"]["recommendations"].append(
                recommendation
            )

        return api_result
