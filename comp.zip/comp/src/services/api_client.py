import os
import time
from typing import Optional, List, Dict, Any
import requests
from dotenv import load_dotenv

from models import (
    Landmark,
    House,
    HouseListing,
    SearchResult,
    LandmarkCategory,
    ListingPlatform,
    HouseStatus,
)

load_dotenv()


class APIClient:
    def __init__(self):
        self.base_url = os.getenv("API_BASE_URL", "http://localhost:8080")
        self.user_id = os.getenv("USER_ID", "test_user")
        self.timeout = int(os.getenv("API_TIMEOUT", 30))
        self.session = requests.Session()
        self._cache = {}
        self._cache_ttl = 60

    def _get_headers(self, require_user_id: bool = True) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if require_user_id:
            headers["X-User-ID"] = self.user_id
        return headers

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        require_user_id: bool = True,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        cache_key = f"{method}:{url}:{str(params)}"

        if method == "GET" and cache_key in self._cache:
            cached_data, timestamp = self._cache[cache_key]
            if time.time() - timestamp < self._cache_ttl:
                return cached_data

        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=data,
                headers=self._get_headers(require_user_id),
                timeout=self.timeout,
            )
            response.raise_for_status()
            result = response.json()

            if method == "GET":
                self._cache[cache_key] = (result, time.time())

            return result
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {e}")

    def reset_house_data(self) -> bool:
        try:
            response = self._make_request("POST", "/api/houses/init")
            return response.get("success", False)
        except:
            return False

    def get_landmarks(
        self,
        category: Optional[LandmarkCategory] = None,
        district: Optional[str] = None,
    ) -> List[Landmark]:
        params = {}
        if category:
            params["category"] = category.value
        if district:
            params["district"] = district

        response = self._make_request(
            "GET", "/api/landmarks", params, require_user_id=False
        )
        return [Landmark(**item) for item in response.get("data", [])]

    def get_landmark_by_name(self, name: str) -> Optional[Landmark]:
        response = self._make_request(
            "GET", f"/api/landmarks/name/{name}", require_user_id=False
        )
        data = response.get("data")
        return Landmark(**data) if data else None

    def search_landmarks(
        self,
        keyword: str,
        category: Optional[LandmarkCategory] = None,
        district: Optional[str] = None,
    ) -> List[Landmark]:
        params = {"keyword": keyword}
        if category:
            params["category"] = category.value
        if district:
            params["district"] = district

        response = self._make_request(
            "GET", "/api/landmarks/search", params, require_user_id=False
        )
        return [Landmark(**item) for item in response.get("data", [])]

    def get_landmark_by_id(self, landmark_id: str) -> Optional[Landmark]:
        response = self._make_request(
            "GET", f"/api/landmarks/{landmark_id}", require_user_id=False
        )
        data = response.get("data")
        return Landmark(**data) if data else None

    def get_house_by_id(self, house_id: str) -> Optional[House]:
        response = self._make_request("GET", f"/api/houses/{house_id}")
        data = response.get("data")
        return House(**data) if data else None

    def get_house_listings(self, house_id: str) -> List[HouseListing]:
        response = self._make_request("GET", f"/api/houses/listings/{house_id}")
        items = response.get("data", {}).get("items", [])
        return [HouseListing(**item) for item in items]

    def get_houses_by_community(
        self,
        community: str,
        page: int = 1,
        page_size: int = 10,
        platform: Optional[ListingPlatform] = None,
    ) -> SearchResult:
        params = {"community": community, "page": page, "page_size": page_size}
        if platform:
            params["listing_platform"] = platform.value

        response = self._make_request("GET", "/api/houses/by_community", params)
        data = response.get("data", {})

        houses = [House(**item) for item in data.get("items", [])]
        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    def get_houses_by_platform(
        self,
        platform: Optional[ListingPlatform] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> SearchResult:
        params = {"page": page, "page_size": page_size}
        if platform:
            params["listing_platform"] = platform.value

        response = self._make_request("GET", "/api/houses/by_platform", params)
        data = response.get("data", {})

        houses = [House(**item) for item in data.get("items", [])]
        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    def get_houses_nearby(
        self,
        landmark_id: str,
        max_distance: int = 2000,
        page: int = 1,
        page_size: int = 10,
        platform: Optional[ListingPlatform] = None,
    ) -> SearchResult:
        params = {
            "landmark_id": landmark_id,
            "max_distance": max_distance,
            "page": page,
            "page_size": page_size,
        }
        if platform:
            params["listing_platform"] = platform.value

        response = self._make_request("GET", "/api/houses/nearby", params)
        data = response.get("data", {})

        houses = [House(**item) for item in data.get("items", [])]
        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    def get_nearby_landmarks(
        self, community: str, category: LandmarkCategory, max_distance: int = 3000
    ) -> List[Landmark]:
        params = {
            "community": community,
            "category": category.value,
            "max_distance_m": max_distance,
        }

        response = self._make_request("GET", "/api/houses/nearby_landmarks", params)
        return [Landmark(**item) for item in response.get("data", [])]

    def get_house_stats(self) -> Dict[str, Any]:
        response = self._make_request("GET", "/api/houses/stats")
        return response.get("data", {})

    def rent_house(self, house_id: str, platform: ListingPlatform) -> bool:
        data = {"listing_platform": platform.value}
        response = self._make_request("POST", f"/api/houses/{house_id}/rent", data=data)
        return response.get("success", False)

    def terminate_rent(self, house_id: str, platform: ListingPlatform) -> bool:
        data = {"listing_platform": platform.value}
        response = self._make_request(
            "POST", f"/api/houses/{house_id}/terminate", data=data
        )
        return response.get("success", False)

    def offline_house(self, house_id: str, platform: ListingPlatform) -> bool:
        data = {"listing_platform": platform.value}
        response = self._make_request(
            "POST", f"/api/houses/{house_id}/offline", data=data
        )
        return response.get("success", False)
