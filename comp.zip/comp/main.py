#!/usr/bin/env python3
import os
import sys
import json
from typing import Optional
from dotenv import load_dotenv

from src.agents.rental_agent import RentalAgent
from src.utils.formatter import OutputFormatter
from src.utils.optimizer import TokenOptimizer

load_dotenv()


class RentalAgentApp:
    def __init__(self):
        self.agent = RentalAgent()
        self.formatter = OutputFormatter()
        self.optimizer = TokenOptimizer()

        api_client = self.agent.api_client
        api_client._make_request = self.optimizer.track_api_call(
            api_client._make_request
        )

    def run_interactive(self):
        print("=" * 60)
        print("🏡 租房智能体 v1.0")
        print("=" * 60)
        print("输入您的租房需求，例如：")
        print("  • '海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤'")
        print("  • '朝阳区精装修两室一厅，面积80平左右，朝南'")
        print("  • '输入 quit 退出程序'")
        print("=" * 60)

        while True:
            try:
                query = input("\n📝 请输入您的需求: ").strip()

                if query.lower() in ["quit", "exit", "q"]:
                    print("\n感谢使用租房智能体！")
                    break

                if not query:
                    print("请输入有效的需求描述")
                    continue

                print(f"\n🔍 正在搜索: {query}")
                print("正在分析需求、搜索房源、计算匹配度...")

                result = self.agent.process_query(query)

                print("\n" + self.formatter.format_summary(result))

                recommendations = [
                    Recommendation(**rec_data)
                    for rec_data in result.get("recommendations", [])
                ]

                if recommendations:
                    print(self.formatter.format_quick_view(recommendations))

                    show_details = (
                        input("\n📋 是否查看详细推荐？(y/n): ").strip().lower()
                    )
                    if show_details == "y":
                        print("\n" + "=" * 60)
                        print("🏠 详细推荐房源")
                        print("=" * 60)
                        for i, rec in enumerate(recommendations):
                            print(self.formatter.format_recommendation(rec, i))

                    rent_option = input(
                        "\n🏠 是否要租赁某套房源？输入编号或按回车跳过: "
                    ).strip()
                    if rent_option.isdigit():
                        idx = int(rent_option) - 1
                        if 0 <= idx < len(recommendations):
                            rec = recommendations[idx]
                            confirm = (
                                input(
                                    f"确认租赁 {rec.house.community} (价格: {rec.house.price}元/月)? (y/n): "
                                )
                                .strip()
                                .lower()
                            )
                            if confirm == "y":
                                success = self.agent.rent_house(rec.house.id)
                                if success:
                                    print("✅ 租赁成功！")
                                else:
                                    print("❌ 租赁失败，请稍后重试")
                else:
                    print("❌ 未找到符合条件的房源，请调整您的需求")

                self.optimizer.print_stats()

            except KeyboardInterrupt:
                print("\n\n程序被中断")
                break
            except Exception as e:
                print(f"❌ 发生错误: {e}")
                continue

    def run_batch(self, queries_file: str, output_file: Optional[str] = None):
        try:
            with open(queries_file, "r", encoding="utf-8") as f:
                queries = [line.strip() for line in f if line.strip()]

            results = []

            for i, query in enumerate(queries):
                print(f"\n[{i + 1}/{len(queries)}] 处理: {query}")

                try:
                    result = self.agent.process_query(query)
                    results.append(
                        {
                            "query": query,
                            "result": self.formatter.format_for_api(result),
                        }
                    )

                    recommendations = [
                        Recommendation(**rec_data)
                        for rec_data in result.get("recommendations", [])
                    ]

                    if recommendations:
                        print(f"  找到 {len(recommendations)} 个推荐房源")
                    else:
                        print("  未找到符合条件的房源")

                except Exception as e:
                    print(f"  处理失败: {e}")
                    results.append({"query": query, "error": str(e)})

            if output_file:
                with open(output_file, "w", encoding="utf-8") as f:
                    json.dump(results, f, ensure_ascii=False, indent=2)
                print(f"\n✅ 结果已保存到: {output_file}")

            self.optimizer.print_stats()

            return results

        except FileNotFoundError:
            print(f"❌ 文件不存在: {queries_file}")
            return []

    def run_single(self, query: str, output_format: str = "text"):
        print(f"\n🔍 处理单条查询: {query}")

        try:
            result = self.agent.process_query(query)

            if output_format == "json":
                api_result = self.formatter.format_for_api(result)
                print(json.dumps(api_result, ensure_ascii=False, indent=2))
            else:
                print(self.formatter.format_summary(result))

                recommendations = [
                    Recommendation(**rec_data)
                    for rec_data in result.get("recommendations", [])
                ]

                if recommendations:
                    for i, rec in enumerate(recommendations):
                        print(self.formatter.format_recommendation(rec, i))

            self.optimizer.print_stats()

            return result

        except Exception as e:
            print(f"❌ 处理失败: {e}")
            return None


def main():
    if len(sys.argv) > 1:
        app = RentalAgentApp()

        if sys.argv[1] == "--batch" and len(sys.argv) > 2:
            output_file = sys.argv[3] if len(sys.argv) > 3 else "results.json"
            app.run_batch(sys.argv[2], output_file)
        elif sys.argv[1] == "--single" and len(sys.argv) > 2:
            output_format = sys.argv[3] if len(sys.argv) > 3 else "text"
            app.run_single(sys.argv[2], output_format)
        elif sys.argv[1] == "--test":
            test_queries = [
                "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
                "朝阳区精装修两室一厅，面积80平左右，朝南",
                "西二旗附近合租单间，预算2k，安静",
            ]
            for query in test_queries:
                print(f"\n{'=' * 60}")
                print(f"测试查询: {query}")
                print("=" * 60)
                app.run_single(query)
        elif sys.argv[1] in ["--help", "-h"]:
            print_help()
        else:
            print("无效参数")
            print_help()
    else:
        app = RentalAgentApp()
        app.run_interactive()


def print_help():
    print("租房智能体使用说明:")
    print("  python main.py                    # 交互式模式")
    print("  python main.py --single <查询>    # 单次查询")
    print("  python main.py --batch <文件>     # 批量处理")
    print("  python main.py --test            # 运行测试")
    print("  python main.py --help            # 显示帮助")
    print("\n示例:")
    print("  python main.py --single '海淀区整租，预算5k以内'")
    print("  python main.py --batch queries.txt results.json")


if __name__ == "__main__":
    main()
