"""
租房智能体核心模块 - 第一部分
实现智能需求解析、房源搜索、评分推荐等核心功能
"""

import asyncio
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import logging
import re
from collections import defaultdict

from ..models import (
    UserRequirement,
    House,
    Recommendation,
    HouseType,
    Decoration,
    Orientation,
    NoiseLevel,
    ListingPlatform,
    RentalQuery,
    RentalResponse,
)
from ..services.openai_service import OpenAIService, get_openai_service
from ..services.rental_api_client import RentalAPIClient, get_rental_client

# 配置日志
logger = logging.getLogger(__name__)


class RequirementParser:
    """
    需求解析器
    结合规则匹配和AI解析，从用户查询中提取结构化需求
    """

    def __init__(self, openai_service: OpenAIService):
        """
        初始化需求解析器

        Args:
            openai_service: OpenAI服务实例
        """
        self.openai_service = openai_service

        # 规则匹配字典
        self.district_keywords = {
            "海淀": "海淀",
            "朝阳": "朝阳",
            "通州": "通州",
            "昌平": "昌平",
            "大兴": "大兴",
            "房山": "房山",
            "西城": "西城",
            "丰台": "丰台",
            "顺义": "顺义",
            "东城": "东城",
            "石景山": "石景山",
        }

        self.house_type_keywords = {
            "整租": HouseType.ENTIRE,
            "合租": HouseType.SHARED,
            "单间": HouseType.SHARED,
            "整套": HouseType.ENTIRE,
        }

        self.decoration_keywords = {
            "精装": Decoration.FINE,
            "精装修": Decoration.FINE,
            "豪华": Decoration.LUXURY,
            "豪华装修": Decoration.LUXURY,
            "简装": Decoration.SIMPLE,
            "简单装修": Decoration.SIMPLE,
            "毛坯": Decoration.ROUGH,
            "空房": Decoration.EMPTY,
        }

        self.orientation_keywords = {
            "朝南": Orientation.SOUTH,
            "南北": Orientation.SOUTH_NORTH,
            "南北通透": Orientation.SOUTH_NORTH,
            "朝北": Orientation.NORTH,
            "朝东": Orientation.EAST,
            "朝西": Orientation.WEST,
            "东西": Orientation.EAST_WEST,
        }

        self.noise_keywords = {
            "安静": NoiseLevel.QUIET,
            "不吵": NoiseLevel.QUIET,
            "中等": NoiseLevel.MEDIUM,
            "吵闹": NoiseLevel.NOISY,
            "临街": NoiseLevel.STREET,
            "不临街": NoiseLevel.QUIET,
        }

        # 正则表达式模式
        self.patterns = {
            "price": [
                r"(\d+)[kK]\s*以内",
                r"不超过\s*(\d+)[kK]",
                r"(\d+)[kK]\s*以下",
                r"预算\s*(\d+)[kK]",
                r"(\d+)\s*到\s*(\d+)[kK]",
                r"(\d+)-(\d+)[kK]",
                r"(\d+)\s*元",
                r"租金\s*(\d+)",
                r"月租\s*(\d+)",
            ],
            "layout": [
                r"(\d+)室",
                r"(\d+)居",
                r"(\d+)房",
                r"(\d+)\s*室\s*(\d+)\s*厅",
                r"一室",
                r"两室",
                r"三室",
                r"四室",
            ],
            "area": [r"(\d+)\s*平", r"面积\s*(\d+)", r"(\d+)\s*平米", r"(\d+)\s*㎡"],
            "subway": [r"近地铁", r"地铁附近", r"地铁口", r"地铁旁", r"离地铁近"],
            "commute": [
                r"(\d+)\s*分钟.*通勤",
                r"通勤\s*(\d+)\s*分钟",
                r"到西二旗\s*(\d+)\s*分钟",
                r"上班\s*(\d+)\s*分钟",
            ],
            "date": [
                r"(\d+)月(\d+)日",
                r"(\d+)[/.-](\d+)",
                r"(\d+)\s*号",
                r"立即入住",
                r"随时入住",
                r"下个月",
            ],
        }

    async def parse(self, query_text: str) -> UserRequirement:
        """
        解析用户查询

        策略：先使用规则匹配快速提取，再使用AI进行深度解析

        Args:
            query_text: 用户查询文本

        Returns:
            UserRequirement: 结构化的用户需求
        """
        logger.info(f"开始解析用户查询: {query_text[:100]}...")

        # 第一步：使用规则匹配快速提取
        rule_based_req = self._rule_based_parse(query_text)

        # 第二步：使用AI进行深度解析
        try:
            ai_based_req = await self.openai_service.parse_requirement(query_text)

            # 第三步：合并两种解析结果（AI结果优先，规则结果作为补充）
            merged_req = self._merge_requirements(ai_based_req, rule_based_req)

            logger.info(f"需求解析完成: {merged_req.dict(exclude_none=True)}")
            return merged_req

        except Exception as e:
            logger.warning(f"AI解析失败，使用规则解析结果: {e}")
            return rule_based_req

    def _rule_based_parse(self, text: str) -> UserRequirement:
        """
        基于规则的解析

        Args:
            text: 查询文本

        Returns:
            UserRequirement: 规则解析结果
        """
        requirement = UserRequirement()

        # 解析价格
        for pattern in self.patterns["price"]:
            matches = re.findall(pattern, text)
            for match in matches:
                if isinstance(match, tuple) and len(match) == 2:
                    min_price = self._parse_price(match[0])
                    max_price = self._parse_price(match[1])
                    requirement.min_price = min_price
                    requirement.max_price = max_price
                else:
                    price = self._parse_price(match)
                    requirement.max_price = price

        # 解析行政区
        districts = []
        for keyword, district in self.district_keywords.items():
            if keyword in text:
                districts.append(district)
        if districts:
            requirement.districts = list(set(districts))  # 去重

        # 解析房屋类型
        for keyword, house_type in self.house_type_keywords.items():
            if keyword in text:
                requirement.house_type = house_type
                break

        # 解析户型
        for pattern in self.patterns["layout"]:
            match = re.search(pattern, text)
            if match:
                if match.group(0) in ["一室", "两室", "三室", "四室"]:
                    chinese_to_num = {"一": "1", "两": "2", "三": "3", "四": "4"}
                    num = chinese_to_num.get(match.group(0)[0], "1")
                    requirement.layout = f"{num}室"
                else:
                    rooms = match.group(1)
                    requirement.layout = f"{rooms}室"
                break

        # 解析面积
        for pattern in self.patterns["area"]:
            match = re.search(pattern, text)
            if match:
                area = float(match.group(1))
                requirement.min_area = area * 0.8
                requirement.max_area = area * 1.2
                break

        # 解析地铁距离
        for pattern in self.patterns["subway"]:
            if re.search(pattern, text):
                requirement.max_subway_distance = 800
                break

        # 解析通勤时间
        for pattern in self.patterns["commute"]:
            match = re.search(pattern, text)
            if match:
                requirement.max_commute_time = int(match.group(1))
                break

        # 解析装修
        for keyword, decoration in self.decoration_keywords.items():
            if keyword in text:
                requirement.decoration = decoration
                break

        # 解析朝向
        for keyword, orientation in self.orientation_keywords.items():
            if keyword in text:
                requirement.orientation = orientation
                break

        # 解析噪音
        for keyword, noise in self.noise_keywords.items():
            if keyword in text:
                requirement.noise_level = noise
                break

        # 解析地标
        landmark_keywords = [
            "西二旗",
            "国贸",
            "望京",
            "中关村",
            "上地",
            "金融街",
            "CBD",
        ]
        landmarks = []
        for keyword in landmark_keywords:
            if keyword in text:
                landmarks.append(keyword)
        if landmarks:
            requirement.target_landmarks = landmarks

        return requirement

    def _parse_price(self, price_str: str) -> int:
        """
        解析价格字符串

        Args:
            price_str: 价格字符串

        Returns:
            int: 价格数值
        """
        try:
            # 处理"5k"格式
            if "k" in price_str.lower():
                num = float(re.search(r"(\d+(\.\d+)?)", price_str).group(1))
                return int(num * 1000)
            # 处理纯数字
            else:
                return int(float(price_str))
        except:
            return 0

    def _merge_requirements(
        self, ai_req: UserRequirement, rule_req: UserRequirement
    ) -> UserRequirement:
        """
        合并AI解析和规则解析的结果

        Args:
            ai_req: AI解析结果
            rule_req: 规则解析结果

        Returns:
            UserRequirement: 合并后的结果
        """
        merged = UserRequirement()

        # 价格：使用AI结果，如果没有则使用规则结果
        merged.max_price = ai_req.max_price or rule_req.max_price
        merged.min_price = ai_req.min_price or rule_req.min_price

        # 行政区：合并两者
        districts = set()
        if ai_req.districts:
            districts.update(ai_req.districts)
        if rule_req.districts:
            districts.update(rule_req.districts)
        if districts:
            merged.districts = list(districts)

        # 其他字段：AI结果优先
        merged.house_type = ai_req.house_type or rule_req.house_type
        merged.layout = ai_req.layout or rule_req.layout
        merged.min_area = ai_req.min_area or rule_req.min_area
        merged.max_area = ai_req.max_area or rule_req.max_area
        merged.max_subway_distance = (
            ai_req.max_subway_distance or rule_req.max_subway_distance
        )
        merged.max_commute_time = ai_req.max_commute_time or rule_req.max_commute_time
        merged.target_landmarks = ai_req.target_landmarks or rule_req.target_landmarks
        merged.decoration = ai_req.decoration or rule_req.decoration
        merged.orientation = ai_req.orientation or rule_req.orientation
        merged.min_bathrooms = ai_req.min_bathrooms or rule_req.min_bathrooms
        merged.noise_level = ai_req.noise_level or rule_req.noise_level
        merged.tags = ai_req.tags or rule_req.tags
        merged.available_date = ai_req.available_date or rule_req.available_date

        return merged


class HouseScorer:
    """
    房源评分器
    根据用户需求对房源进行综合评分
    """

    def __init__(self):
        """
        初始化评分器

        评分权重配置：
        - 价格：25% - 最重要的因素
        - 位置：20% - 行政区、地段
        - 通勤：15% - 地铁距离、通勤时间
        - 条件：15% - 装修、朝向、面积等
        - 标签：10% - 房源标签
        - 平台：10% - 多平台验证
        - AI额外：5% - AI分析的额外加分
        """
        self.weights = {
            "price": 0.25,
            "location": 0.20,
            "commute": 0.15,
            "condition": 0.15,
            "tags": 0.10,
            "platforms": 0.10,
            "ai_extra": 0.05,
        }

        # 标签权重
        self.tag_weights = {
            "positive": {
                "近地铁": 3,
                "双地铁": 5,
                "多地铁": 4,
                "精装修": 3,
                "豪华装修": 4,
                "朝南": 3,
                "南北通透": 4,
                "采光好": 2,
                "有电梯": 2,
                "高楼层": 1,
                "高层": 1,
                "核心区": 3,
                "学区房": 4,
                "近高校": 2,
                "双卫": 2,
                "大户型": 1,
                "大三居": 2,
            },
            "negative": {
                "临街": -3,
                "毛坯": -2,
                "空房": -2,
                "农村房": -3,
                "农村自建房": -3,
                "吵闹": -2,
                "低楼层": -1,
            },
        }

    def calculate_score(
        self, house: House, requirement: UserRequirement, listings: List[Any] = None
    ) -> Tuple[float, List[str], Dict[str, float]]:
        """
        计算房源评分

        Args:
            house: 房源信息
            requirement: 用户需求
            listings: 房源挂牌记录

        Returns:
            Tuple[评分, 理由列表, 详细得分]
        """
        score_details = {}
        reasons = []

        # 1. 价格评分 (25%)
        price_score, price_reasons = self._calculate_price_score(
            house.price, requirement
        )
        score_details["price"] = price_score
        reasons.extend(price_reasons)

        # 2. 位置评分 (20%)
        location_score, location_reasons = self._calculate_location_score(
            house, requirement
        )
        score_details["location"] = location_score
        reasons.extend(location_reasons)

        # 3. 通勤评分 (15%)
        commute_score, commute_reasons = self._calculate_commute_score(
            house, requirement
        )
        score_details["commute"] = commute_score
        reasons.extend(commute_reasons)

        # 4. 条件评分 (15%)
        condition_score, condition_reasons = self._calculate_condition_score(
            house, requirement
        )
        score_details["condition"] = condition_score
        reasons.extend(condition_reasons)

        # 5. 标签评分 (10%)
        tags_score, tags_reasons = self._calculate_tags_score(house.tags)
        score_details["tags"] = tags_score
        reasons.extend(tags_reasons)

        # 6. 平台评分 (10%)
        platforms_score, platforms_reasons = self._calculate_platforms_score(listings)
        score_details["platforms"] = platforms_score
        reasons.extend(platforms_reasons)

        # 7. 计算加权总分
        total_score = 0
        for category, weight in self.weights.items():
            if category in score_details:
                total_score += score_details[category] * weight

        # 确保分数在0-100之间
        total_score = max(0, min(100, total_score))

        return total_score, reasons, score_details

    def _calculate_price_score(
        self, price: int, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        """
        计算价格评分

        Args:
            price: 房源价格
            requirement: 用户需求

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []

        if requirement.max_price and price > requirement.max_price:
            # 超出预算，严重扣分
            overshoot_ratio = (price - requirement.max_price) / requirement.max_price
            if overshoot_ratio > 0.5:  # 超出50%以上
                score = 20
                reasons.append(f"价格{price}元严重超出预算")
            elif overshoot_ratio > 0.2:  # 超出20%-50%
                score = 40
                reasons.append(f"价格{price}元超出预算较多")
            else:  # 超出20%以内
                score = 60
                reasons.append(f"价格{price}元略超预算")

        elif requirement.min_price and price < requirement.min_price:
            # 低于最低预算，可能质量有问题
            score = 70
            reasons.append(f"价格{price}元较低，需注意房屋条件")

        elif requirement.max_price:
            # 在预算范围内，根据性价比评分
            price_ratio = price / requirement.max_price
            if price_ratio < 0.7:  # 价格低于预算70%，性价比高
                score = 95
                reasons.append(f"价格{price}元性价比高")
            elif price_ratio < 0.9:  # 价格在预算70%-90%之间
                score = 85
                reasons.append(f"价格{price}元合理")
            else:  # 价格接近预算上限
                score = 75
                reasons.append(f"价格{price}元接近预算上限")
        else:
            # 没有价格要求
            score = 80
            reasons.append(f"价格{price}元")

        return score, reasons
