"""
租房智能体核心模块 - 第二部分
继续实现房源评分器和智能体主类
"""

import asyncio
import time
import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import logging

from ..models import (
    UserRequirement,
    House,
    Recommendation,
    HouseType,
    Decoration,
    Orientation,
    NoiseLevel,
    ListingPlatform,
    RentalQuery,
    RentalResponse,
)
from ..services.openai_service import OpenAIService, get_openai_service
from ..services.rental_api_client import RentalAPIClient, get_rental_client

# 配置日志
logger = logging.getLogger(__name__)


class HouseScorer:
    """
    房源评分器
    根据用户需求对房源进行综合评分
    """

    def __init__(self):
        """
        初始化评分器

        评分权重配置：
        - 价格：25% - 最重要的因素
        - 位置：20% - 行政区、地段
        - 通勤：15% - 地铁距离、通勤时间
        - 条件：15% - 装修、朝向、面积等
        - 标签：10% - 房源标签
        - 平台：10% - 多平台验证
        - AI额外：5% - AI分析的额外加分
        """
        self.weights = {
            "price": 0.25,
            "location": 0.20,
            "commute": 0.15,
            "condition": 0.15,
            "tags": 0.10,
            "platforms": 0.10,
            "ai_extra": 0.05,
        }

        # 标签权重
        self.tag_weights = {
            "positive": {
                "近地铁": 3,
                "双地铁": 5,
                "多地铁": 4,
                "精装修": 3,
                "豪华装修": 4,
                "朝南": 3,
                "南北通透": 4,
                "采光好": 2,
                "有电梯": 2,
                "高楼层": 1,
                "高层": 1,
                "核心区": 3,
                "学区房": 4,
                "近高校": 2,
                "双卫": 2,
                "大户型": 1,
                "大三居": 2,
            },
            "negative": {
                "临街": -3,
                "毛坯": -2,
                "空房": -2,
                "农村房": -3,
                "农村自建房": -3,
                "吵闹": -2,
                "低楼层": -1,
            },
        }

    def calculate_score(
        self, house: House, requirement: UserRequirement, listings: List[Any] = None
    ) -> Tuple[float, List[str], Dict[str, float]]:
        """
        计算房源评分

        Args:
            house: 房源信息
            requirement: 用户需求
            listings: 房源挂牌记录

        Returns:
            Tuple[评分, 理由列表, 详细得分]
        """
        score_details = {}
        reasons = []

        # 1. 价格评分 (25%)
        price_score, price_reasons = self._calculate_price_score(
            house.price, requirement
        )
        score_details["price"] = price_score
        reasons.extend(price_reasons)

        # 2. 位置评分 (20%)
        location_score, location_reasons = self._calculate_location_score(
            house, requirement
        )
        score_details["location"] = location_score
        reasons.extend(location_reasons)

        # 3. 通勤评分 (15%)
        commute_score, commute_reasons = self._calculate_commute_score(
            house, requirement
        )
        score_details["commute"] = commute_score
        reasons.extend(commute_reasons)

        # 4. 条件评分 (15%)
        condition_score, condition_reasons = self._calculate_condition_score(
            house, requirement
        )
        score_details["condition"] = condition_score
        reasons.extend(condition_reasons)

        # 5. 标签评分 (10%)
        tags_score, tags_reasons = self._calculate_tags_score(house.tags)
        score_details["tags"] = tags_score
        reasons.extend(tags_reasons)

        # 6. 平台评分 (10%)
        platforms_score, platforms_reasons = self._calculate_platforms_score(listings)
        score_details["platforms"] = platforms_score
        reasons.extend(platforms_reasons)

        # 7. 计算加权总分
        total_score = 0
        for category, weight in self.weights.items():
            if category in score_details:
                total_score += score_details[category] * weight

        # 确保分数在0-100之间
        total_score = max(0, min(100, total_score))

        return total_score, reasons, score_details

    def _calculate_price_score(
        self, price: int, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        """
        计算价格评分

        Args:
            price: 房源价格
            requirement: 用户需求

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []

        if requirement.max_price and price > requirement.max_price:
            # 超出预算，严重扣分
            overshoot_ratio = (price - requirement.max_price) / requirement.max_price
            if overshoot_ratio > 0.5:  # 超出50%以上
                score = 20
                reasons.append(f"价格{price}元严重超出预算")
            elif overshoot_ratio > 0.2:  # 超出20%-50%
                score = 40
                reasons.append(f"价格{price}元超出预算较多")
            else:  # 超出20%以内
                score = 60
                reasons.append(f"价格{price}元略超预算")

        elif requirement.min_price and price < requirement.min_price:
            # 低于最低预算，可能质量有问题
            score = 70
            reasons.append(f"价格{price}元较低，需注意房屋条件")

        elif requirement.max_price:
            # 在预算范围内，根据性价比评分
            price_ratio = price / requirement.max_price
            if price_ratio < 0.7:  # 价格低于预算70%，性价比高
                score = 95
                reasons.append(f"价格{price}元性价比高")
            elif price_ratio < 0.9:  # 价格在预算70%-90%之间
                score = 85
                reasons.append(f"价格{price}元合理")
            else:  # 价格接近预算上限
                score = 75
                reasons.append(f"价格{price}元接近预算上限")
        else:
            # 没有价格要求
            score = 80
            reasons.append(f"价格{price}元")

        return score, reasons

    def _calculate_location_score(
        self, house: House, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        """
        计算位置评分

        Args:
            house: 房源信息
            requirement: 用户需求

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []
        score = 80  # 基础分

        # 行政区匹配
        if requirement.districts and house.district in requirement.districts:
            score += 15
            reasons.append(f"位于目标区域{house.district}区")
        elif requirement.districts:
            score -= 20
            reasons.append(f"区域{house.district}区不符合要求")
        else:
            reasons.append(f"位于{house.district}区")

        # 小区评分（简单版本）
        if "核心区" in house.tags:
            score += 5
            reasons.append("位于核心区域")

        if "学区房" in house.tags:
            score += 8
            reasons.append("学区房，教育资源好")

        return min(100, max(0, score)), reasons

    def _calculate_commute_score(
        self, house: House, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        """
        计算通勤评分

        Args:
            house: 房源信息
            requirement: 用户需求

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []
        score = 80  # 基础分

        # 地铁距离评分
        if requirement.max_subway_distance:
            if house.subway_distance <= requirement.max_subway_distance:
                if house.subway_distance <= 500:
                    score += 15
                    reasons.append(f"距地铁仅{house.subway_distance}米，非常便利")
                elif house.subway_distance <= 800:
                    score += 10
                    reasons.append(f"距地铁{house.subway_distance}米，步行可达")
                else:
                    score += 5
                    reasons.append(f"距地铁{house.subway_distance}米")
            else:
                distance_over = house.subway_distance - requirement.max_subway_distance
                penalty = min(30, distance_over / 50)  # 每超出50米扣1分，最多扣30分
                score -= penalty
                reasons.append(f"距地铁{house.subway_distance}米较远")
        else:
            if house.subway_distance <= 800:
                score += 10
                reasons.append(f"近地铁({house.subway_distance}米)")
            else:
                reasons.append(f"距地铁{house.subway_distance}米")

        # 西二旗通勤时间评分
        if requirement.max_commute_time:
            if house.xierqi_commute <= requirement.max_commute_time:
                if house.xierqi_commute <= 30:
                    score += 10
                    reasons.append(f"西二旗通勤仅{house.xierqi_commute}分钟")
                else:
                    score += 5
                    reasons.append(f"西二旗通勤{house.xierqi_commute}分钟")
            else:
                time_over = house.xierqi_commute - requirement.max_commute_time
                penalty = min(25, time_over / 2)  # 每超出2分钟扣1分，最多扣25分
                score -= penalty
                reasons.append(f"西二旗通勤{house.xierqi_commute}分钟较长")
        else:
            if house.xierqi_commute <= 45:
                score += 5
                reasons.append(f"西二旗通勤{house.xierqi_commute}分钟合理")
            else:
                reasons.append(f"西二旗通勤{house.xierqi_commute}分钟")

        return min(100, max(0, score)), reasons

    def _calculate_condition_score(
        self, house: House, requirement: UserRequirement
    ) -> Tuple[float, List[str]]:
        """
        计算房屋条件评分

        Args:
            house: 房源信息
            requirement: 用户需求

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []
        score = 80  # 基础分

        # 装修匹配
        if requirement.decoration and house.decoration == requirement.decoration:
            score += 8
            reasons.append(f"装修{house.decoration.value}符合要求")
        elif requirement.decoration:
            score -= 5
            reasons.append(
                f"装修{house.decoration.value}不符合{requirement.decoration.value}要求"
            )
        else:
            if house.decoration in [Decoration.FINE, Decoration.LUXURY]:
                score += 5
                reasons.append(f"装修{house.decoration.value}良好")
            else:
                reasons.append(f"装修{house.decoration.value}")

        # 朝向匹配
        if requirement.orientation and house.orientation == requirement.orientation:
            score += 5
            reasons.append(f"朝向{house.orientation.value}符合要求")
        elif requirement.orientation:
            score -= 3
            reasons.append(
                f"朝向{house.orientation.value}不符合{requirement.orientation.value}要求"
            )
        else:
            if house.orientation in [Orientation.SOUTH, Orientation.SOUTH_NORTH]:
                score += 3
                reasons.append(f"朝向{house.orientation.value}采光好")
            else:
                reasons.append(f"朝向{house.orientation.value}")

        # 面积匹配
        if requirement.min_area and house.area < requirement.min_area:
            area_ratio = house.area / requirement.min_area
            penalty = min(10, (1 - area_ratio) * 20)  # 面积不足扣分
            score -= penalty
            reasons.append(f"面积{house.area}㎡偏小")
        elif requirement.max_area and house.area > requirement.max_area:
            area_ratio = house.area / requirement.max_area
            penalty = min(5, (area_ratio - 1) * 10)  # 面积过大扣分
            score -= penalty
            reasons.append(f"面积{house.area}㎡偏大")
        else:
            if 60 <= house.area <= 100:  # 理想面积范围
                score += 3
                reasons.append(f"面积{house.area}㎡适中")
            else:
                reasons.append(f"面积{house.area}㎡")

        # 卫生间数量
        if requirement.min_bathrooms and house.bathrooms < requirement.min_bathrooms:
            score -= 3
            reasons.append(f"{house.bathrooms}个卫生间不足")
        else:
            if house.bathrooms >= 2:
                score += 2
                reasons.append(f"{house.bathrooms}个卫生间")
            else:
                reasons.append(f"{house.bathrooms}个卫生间")

        # 噪音水平
        if requirement.noise_level:
            if requirement.noise_level == NoiseLevel.QUIET and house.noise_level in [
                NoiseLevel.NOISY,
                NoiseLevel.STREET,
            ]:
                score -= 8
                reasons.append(f"噪音{house.noise_level.value}不符合安静要求")
            elif house.noise_level != requirement.noise_level:
                score -= 3
                reasons.append(f"噪音{house.noise_level.value}可能不理想")
            else:
                score += 3
                reasons.append(f"噪音{house.noise_level.value}符合要求")
        else:
            if house.noise_level == NoiseLevel.QUIET:
                score += 3
                reasons.append(f"环境{house.noise_level.value}")
            else:
                reasons.append(f"噪音水平{house.noise_level.value}")

        return min(100, max(0, score)), reasons

    def _calculate_tags_score(self, tags: List[str]) -> Tuple[float, List[str]]:
        """
        计算标签评分

        Args:
            tags: 房源标签列表

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []
        score = 80  # 基础分

        tag_score = 0
        for tag in tags:
            if tag in self.tag_weights["positive"]:
                tag_score += self.tag_weights["positive"][tag]
                reasons.append(f"具有{tag}优势")
            elif tag in self.tag_weights["negative"]:
                tag_score += self.tag_weights["negative"][tag]
                reasons.append(f"存在{tag}劣势")

        # 标签得分转换为0-20分范围
        max_possible_score = sum(self.tag_weights["positive"].values())
        if max_possible_score > 0:
            tags_normalized = (
                (tag_score + abs(min(self.tag_weights["negative"].values(), default=0)))
                / max_possible_score
                * 20
            )
        else:
            tags_normalized = 10

        score += tags_normalized - 10  # 调整到基础分80附近

        return min(100, max(0, score)), reasons

    def _calculate_platforms_score(
        self, listings: List[Any]
    ) -> Tuple[float, List[str]]:
        """
        计算平台验证评分

        Args:
            listings: 房源挂牌记录

        Returns:
            Tuple[评分, 理由列表]
        """
        reasons = []

        if not listings:
            score = 70
            reasons.append("无平台验证，需谨慎")
            return score, reasons

        # 统计不同平台数量
        platforms = set()
        for listing in listings:
            if hasattr(listing, "platform"):
                platforms.add(listing.platform)

        platform_count = len(platforms)

        if platform_count >= 3:
            score = 95
            reasons.append("三平台验证，房源可信度高")
        elif platform_count == 2:
            score = 85
            reasons.append("双平台验证，房源可信")
        else:
            score = 75
            reasons.append("单平台房源")

        return score, reasons


class RentalAgent:
    """
    租房智能体主类
    协调需求解析、房源搜索、评分推荐等流程
    """

    def __init__(
        self,
        openai_service: Optional[OpenAIService] = None,
        api_client: Optional[RentalAPIClient] = None,
    ):
        """
        初始化租房智能体

        Args:
            openai_service: OpenAI服务实例
            api_client: 租房API客户端实例
        """
        self.openai_service = openai_service or get_openai_service()
        self.api_client = api_client

        # 从第一部分导入RequirementParser
        from .rental_agent_part1 import RequirementParser

        self.parser = RequirementParser(self.openai_service)

        self.scorer = HouseScorer()

        # 性能统计
        self.stats = {"total_queries": 0, "avg_processing_time": 0, "success_rate": 0}

    async def initialize(self):
        """初始化智能体"""
        if self.api_client is None:
            self.api_client = await get_rental_client()

        # 重置房源数据（确保每次会话使用初始数据）
        await self.api_client.reset_house_data()
        logger.info("租房智能体初始化完成")

    async def process_query(self, rental_query: RentalQuery) -> RentalResponse:
        """
        处理租房查询

        Args:
            rental_query: 租房查询请求

        Returns:
            RentalResponse: 查询响应
        """
        start_time = time.time()
        self.stats["total_queries"] += 1

        try:
            logger.info(f"处理租房查询: {rental_query.query[:100]}...")

            # 1. 解析用户需求
            requirement = await self.parser.parse(rental_query.query)

            # 2. 搜索房源
            houses = await self._search_houses(requirement)

            # 3. 获取房源详情和挂牌信息
            enriched_houses = await self._enrich_houses(houses)

            # 4. 评分和排序
            recommendations = await self._score_and_rank(
                enriched_houses, requirement, rental_query.query
            )

            # 5. 生成AI分析总结
            ai_analysis = await self._generate_analysis(
                rental_query.query, requirement, recommendations
            )

            # 6. 构建响应
            processing_time = time.time() - start_time

            response = RentalResponse(
                success=True,
                query_analysis=requirement.dict(exclude_none=True),
                recommendations=recommendations,
                total_houses_found=len(houses),
                processing_time=processing_time,
                token_usage=self.openai_service.get_token_usage(),
            )

            # 更新统计
            self._update_stats(processing_time, True)

            logger.info(
                f"查询处理完成: 找到{len(houses)}套房源，推荐{len(recommendations)}套，耗时{processing_time:.2f}秒"
            )

            return response

        except Exception as e:
            processing_time = time.time() - start_time
            logger.error(f"查询处理失败: {e}")

            self._update_stats(processing_time, False)

            return RentalResponse(
                success=False,
                query_analysis={},
                recommendations=[],
                total_houses_found=0,
                processing_time=processing_time,
                error_message=str(e),
            )

    async def _search_houses(
        self, requirement: UserRequirement, max_results: int = 100
    ) -> List[House]:
        """
        根据需求搜索房源

        Args:
            requirement: 用户需求
            max_results: 最大结果数

        Returns:
            List[House]: 搜索到的房源列表
        """
        logger.info(f"开始搜索房源，需求: {requirement.dict(exclude_none=True)}")

        all_houses = []

        # 策略1：根据地标搜索
        if requirement.target_landmarks:
            for landmark_name in requirement.target_landmarks[:2]:  # 最多搜索2个地标
                landmark = await self.api_client.get_landmark_by_name(landmark_name)
                if landmark:
                    logger.info(f"根据地标'{landmark_name}'搜索附近房源")
                    result = await self.api_client.get_houses_nearby(
                        landmark_id=landmark.id, max_distance=2000, page_size=50
                    )
                    all_houses.extend(result.houses)

        # 策略2：根据行政区搜索
        if requirement.districts and len(all_houses) < max_results // 2:
            for district in requirement.districts[:2]:  # 最多搜索2个行政区
                logger.info(f"在行政区'{district}'搜索房源")
                # 获取该行政区的地标
                landmarks = await self.api_client.get_landmarks(district=district)
                for landmark in landmarks[:3]:  # 每个行政区最多3个地标
                    result = await self.api_client.get_houses_nearby(
                        landmark_id=landmark.id, max_distance=3000, page_size=30
                    )
                    all_houses.extend(result.houses)

        # 策略3：通用搜索（如果前两种策略结果不足）
        if not all_houses:
            logger.info("进行通用搜索")
            result = await self.api_client.get_houses_by_platform(page_size=100)
            all_houses = result.houses

        # 去重和过滤
        unique_houses = {}
        for house in all_houses:
            if house.id not in unique_houses and house.status.value == "可租":
                unique_houses[house.id] = house

        filtered_houses = []
        for house in unique_houses.values():
            if self._filter_house(house, requirement):
                filtered_houses.append(house)

        logger.info(
            f"房源搜索完成: 原始{len(all_houses)}套，去重后{len(unique_houses)}套，过滤后{len(filtered_houses)}套"
        )

        return filtered_houses[:max_results]

    def _filter_house(self, house: House, requirement: UserRequirement) -> bool:
        """
        过滤房源（硬性条件）

        Args:
            house: 房源信息
            requirement: 用户需求

        Returns:
            bool: 是否通过过滤
        """
        # 价格过滤
        if requirement.max_price and house.price > requirement.max_price:
            return False

        if requirement.min_price and house.price < requirement.min_price:
            return False

        # 行政区过滤
        if requirement.districts and house.district not in requirement.districts:
            return False

        # 房屋类型过滤
        if requirement.house_type and house.house_type != requirement.house_type:
            return False

        # 户型过滤
        if requirement.layout and requirement.layout not in house.layout:
            return False

        # 地铁距离过滤（硬性条件）
        if (
            requirement.max_subway_distance
            and house.subway_distance > requirement.max_subway_distance
        ):
            return False

        # 通勤时间过滤（硬性条件）
        if (
            requirement.max_commute_time
            and house.xierqi_commute > requirement.max_commute_time
        ):
            return False

        # 装修过滤（如果是硬性要求）
        if requirement.decoration and house.decoration != requirement.decoration:
            # 如果用户明确要求某种装修，严格匹配
            return False

        # 噪音过滤（如果是硬性要求）
        if requirement.noise_level == NoiseLevel.QUIET and house.noise_level in [
            NoiseLevel.NOISY,
            NoiseLevel.STREET,
        ]:
            return False

        return True

    async def _enrich_houses(self, houses: List[House]) -> List[Dict[str, Any]]:
        """
        丰富房源信息（获取挂牌记录等）

        Args:
            houses: 房源列表

        Returns:
            List[Dict]: 丰富后的房源信息列表
        """
        logger.info(f"开始丰富{len(houses)}套房源信息")

        enriched_houses = []

        # 批量获取挂牌信息
        tasks = []
        for house in houses:
            task = self.api_client.get_house_listings(house.id)
            tasks.append((house, task))

        # 并行执行
        for house, task in tasks:
            try:
                listings = await task
                enriched_houses.append({"house": house, "listings": listings})
            except Exception as e:
                logger.warning(f"获取房源{house.id}挂牌信息失败: {e}")
                enriched_houses.append({"house": house, "listings": []})

        logger.info(f"房源信息丰富完成: {len(enriched_houses)}套")
        return enriched_houses

    async def _score_and_rank(
        self,
        enriched_houses: List[Dict[str, Any]],
        requirement: UserRequirement,
        original_query: str,
    ) -> List[Recommendation]:
        """
        评分和排序

        Args:
            enriched_houses: 丰富后的房源信息
            requirement: 用户需求
            original_query: 原始查询

        Returns:
            List[Recommendation]: 推荐列表
        """
        logger.info(f"开始评分和排序: {len(enriched_houses)}套房源")

        scored_houses = []

        for item in enriched_houses:
            house = item["house"]
            listings = item["listings"]

            # 计算基础评分
            score, reasons, score_details = self.scorer.calculate_score(
                house, requirement, listings
            )

            # 获取AI生成的推荐理由
            try:
                ai_reasons = await self.openai_service.generate_recommendation_reasons(
                    house_info=house.dict(),
                    user_requirement=requirement.dict(exclude_none=True),
                    score=score,
                )
                reasons.extend(ai_reasons[:3])  # 添加前3条AI理由
            except Exception as e:
                logger.warning(f"生成AI推荐理由失败: {e}")

            # 创建推荐对象
            recommendation = Recommendation(
                house=house,
                score=score,
                reasons=reasons[:8],  # 最多8条理由
                listings=listings,
            )

            scored_houses.append((score, recommendation))

        # 按评分排序
        scored_houses.sort(key=lambda x: x[0], reverse=True)

        # 取前5名
        top_recommendations = [rec for _, rec in scored_houses[:5]]

        logger.info(
            f"评分排序完成: 推荐{len(top_recommendations)}套，最高分{scored_houses[0][0] if scored_houses else 0}"
        )

        return top_recommendations

    async def _generate_analysis(
        self,
        original_query: str,
        requirement: UserRequirement,
        recommendations: List[Recommendation],
    ) -> str:
        """
        生成AI分析总结

        Args:
            original_query: 原始查询
            requirement: 用户需求
            recommendations: 推荐列表

        Returns:
            str: 分析总结文本
        """
        if not recommendations:
            return "未找到符合条件的房源，建议调整搜索条件"

        try:
            # 准备推荐房源概况
            recommendations_summary = []
            for i, rec in enumerate(recommendations[:3]):  # 只分析前3个
                house = rec.house
                summary = {
                    "rank": i + 1,
                    "community": house.community,
                    "district": house.district,
                    "layout": house.layout,
                    "price": house.price,
                    "score": rec.score,
                    "key_reasons": rec.reasons[:3],
                }
                recommendations_summary.append(summary)

            # 生成AI分析
            analysis = await self.openai_service.generate_analysis_summary(
                user_query=original_query,
                requirement_analysis=requirement.dict(exclude_none=True),
                recommendations_summary=json.dumps(
                    recommendations_summary, ensure_ascii=False, indent=2
                ),
            )

            return analysis

        except Exception as e:
            logger.warning(f"生成AI分析总结失败: {e}")
            return "分析服务暂时不可用"

    def _update_stats(self, processing_time: float, success: bool):
        """
        更新性能统计

        Args:
            processing_time: 处理时间
            success: 是否成功
        """
        # 更新平均处理时间
        total_queries = self.stats["total_queries"]
        current_avg = self.stats["avg_processing_time"]
        new_avg = (current_avg * (total_queries - 1) + processing_time) / total_queries
        self.stats["avg_processing_time"] = new_avg

        # 更新成功率
        if success:
            success_count = self.stats.get("success_count", 0) + 1
            self.stats["success_count"] = success_count
            self.stats["success_rate"] = success_count / total_queries * 100

    def get_stats(self) -> Dict[str, Any]:
        """
        获取智能体统计信息

        Returns:
            Dict[str, Any]: 统计信息
        """
        return {
            **self.stats,
            "openai_service": self.openai_service.get_token_usage()
            if hasattr(self.openai_service, "get_token_usage")
            else {},
        }


# 创建全局智能体实例
_rental_agent: Optional[RentalAgent] = None


async def get_rental_agent() -> RentalAgent:
    """
    获取租房智能体实例（单例模式）

    Returns:
        RentalAgent: 智能体实例
    """
    global _rental_agent
    if _rental_agent is None:
        openai_service = get_openai_service()
        _rental_agent = RentalAgent(openai_service=openai_service)
        await _rental_agent.initialize()

    return _rental_agent
