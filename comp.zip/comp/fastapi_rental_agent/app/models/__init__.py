"""
数据模型模块
定义租房智能体使用的所有数据模型，使用Pydantic进行数据验证
"""

from enum import Enum
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from pydantic import BaseModel, Field, validator


class LandmarkCategory(str, Enum):
    """
    地标类别枚举
    用于分类不同类型的地标点
    """

    SUBWAY = "subway"  # 地铁站
    COMPANY = "company"  # 公司（世界500强企业）
    BUSINESS = "business"  # 商圈
    SUPERMARKET = "supermarket"  # 商超
    PARK = "park"  # 公园


class HouseType(str, Enum):
    """
    房屋类型枚举
    区分整租和合租
    """

    ENTIRE = "entire"  # 整租
    SHARED = "shared"  # 合租


class Decoration(str, Enum):
    """
    装修等级枚举
    从简装到豪华的不同装修标准
    """

    SIMPLE = "简装"  # 简单装修
    FINE = "精装"  # 精装修
    LUXURY = "豪华"  # 豪华装修
    ROUGH = "毛坯"  # 毛坯房
    EMPTY = "空房"  # 空房


class Orientation(str, Enum):
    """
    房屋朝向枚举
    影响采光和通风
    """

    SOUTH = "朝南"  # 朝南，最佳采光
    NORTH = "朝北"  # 朝北，采光较差
    EAST = "朝东"  # 朝东，早晨采光好
    WEST = "朝西"  # 朝西，下午采光好
    SOUTH_NORTH = "南北"  # 南北通透，通风好
    EAST_WEST = "东西"  # 东西通透


class NoiseLevel(str, Enum):
    """
    噪音水平枚举
    影响居住舒适度
    """

    QUIET = "安静"  # 安静环境
    MEDIUM = "中等"  # 中等噪音
    NOISY = "吵闹"  # 吵闹环境
    STREET = "临街"  # 临街，噪音较大


class HouseStatus(str, Enum):
    """
    房源状态枚举
    表示房源的当前状态
    """

    AVAILABLE = "可租"  # 可租赁
    RENTED = "已租"  # 已出租
    OFFLINE = "下架"  # 已下架


class ListingPlatform(str, Enum):
    """
    房源挂牌平台枚举
    不同平台的房源信息
    """

    ANJUKE = "安居客"  # 安居客平台
    LIANJIA = "链家"  # 链家平台
    WUBA = "58同城"  # 58同城平台


class Landmark(BaseModel):
    """
    地标模型
    表示一个地理位置点，如地铁站、公司、商圈等
    """

    id: str = Field(..., description="地标唯一ID")
    name: str = Field(..., description="地标名称")
    category: LandmarkCategory = Field(..., description="地标类别")
    district: str = Field(..., description="所在行政区")
    latitude: float = Field(..., description="纬度坐标")
    longitude: float = Field(..., description="经度坐标")
    description: Optional[str] = Field(None, description="地标描述")


class House(BaseModel):
    """
    房源模型
    表示一套具体的租房房源信息
    """

    id: str = Field(..., description="房源唯一ID")
    address: str = Field(..., description="详细地址")
    district: str = Field(..., description="所在行政区")
    community: str = Field(..., description="小区名称")
    house_type: HouseType = Field(..., description="房屋类型（整租/合租）")
    layout: str = Field(..., description="户型描述，如'2室1厅1卫'")
    area: float = Field(..., description="面积（平方米）")
    price: int = Field(..., description="月租金（元）")
    available_date: str = Field(..., description="可入住日期")
    floor: str = Field(..., description="楼层信息，如'10/20'表示20层中的第10层")
    subway_station: str = Field(..., description="最近地铁站名称")
    subway_distance: int = Field(..., description="到最近地铁站的距离（米）")
    xierqi_commute: int = Field(..., description="到西二旗的通勤时间（分钟）")
    decoration: Decoration = Field(..., description="装修等级")
    orientation: Orientation = Field(..., description="房屋朝向")
    bathrooms: int = Field(..., description="卫生间数量")
    noise_level: NoiseLevel = Field(..., description="噪音水平")
    tags: List[str] = Field(default_factory=list, description="房源标签列表")
    status: HouseStatus = Field(..., description="房源状态")
    latitude: float = Field(..., description="纬度坐标")
    longitude: float = Field(..., description="经度坐标")

    @validator("price")
    def validate_price(cls, v):
        """验证价格在合理范围内"""
        if v < 500 or v > 25000:
            raise ValueError(f"价格{v}超出合理范围(500-25000)")
        return v

    @validator("area")
    def validate_area(cls, v):
        """验证面积在合理范围内"""
        if v < 12 or v > 145:
            raise ValueError(f"面积{v}超出合理范围(12-145)")
        return v


class HouseListing(BaseModel):
    """
    房源挂牌记录模型
    表示房源在不同平台的挂牌信息
    """

    platform: ListingPlatform = Field(..., description="挂牌平台")
    house_id: str = Field(..., description="房源ID")
    price: int = Field(..., description="挂牌价格")
    status: HouseStatus = Field(..., description="挂牌状态")
    posted_at: str = Field(..., description="挂牌时间")


class UserRequirement(BaseModel):
    """
    用户需求模型
    从用户查询中解析出的结构化需求
    """

    max_price: Optional[int] = Field(None, description="最高预算（元）")
    min_price: Optional[int] = Field(None, description="最低预算（元）")
    districts: Optional[List[str]] = Field(None, description="目标行政区列表")
    house_type: Optional[HouseType] = Field(None, description="房屋类型要求")
    layout: Optional[str] = Field(None, description="户型要求，如'2室'")
    min_area: Optional[float] = Field(None, description="最小面积要求（平方米）")
    max_area: Optional[float] = Field(None, description="最大面积要求（平方米）")
    max_subway_distance: Optional[int] = Field(None, description="最大地铁距离（米）")
    max_commute_time: Optional[int] = Field(None, description="最大通勤时间（分钟）")
    target_landmarks: Optional[List[str]] = Field(None, description="目标地标列表")
    decoration: Optional[Decoration] = Field(None, description="装修要求")
    orientation: Optional[Orientation] = Field(None, description="朝向要求")
    min_bathrooms: Optional[int] = Field(None, description="最少卫生间数量")
    noise_level: Optional[NoiseLevel] = Field(None, description="噪音水平要求")
    tags: Optional[List[str]] = Field(None, description="标签要求")
    available_date: Optional[str] = Field(None, description="可入住日期要求")

    class Config:
        """Pydantic配置"""

        use_enum_values = True  # 序列化时使用枚举值


class SearchResult(BaseModel):
    """
    搜索结果模型
    包含搜索到的房源列表和分页信息
    """

    houses: List[House] = Field(default_factory=list, description="房源列表")
    total: int = Field(0, description="总结果数")
    page: int = Field(1, description="当前页码")
    page_size: int = Field(10, description="每页大小")


class Recommendation(BaseModel):
    """
    推荐结果模型
    包含房源、评分、推荐理由和多平台信息
    """

    house: House = Field(..., description="推荐的房源")
    score: float = Field(..., description="匹配度评分(0-100)")
    reasons: List[str] = Field(default_factory=list, description="推荐理由列表")
    listings: List[HouseListing] = Field(
        default_factory=list, description="多平台挂牌信息"
    )
    ai_analysis: Optional[str] = Field(None, description="AI分析总结")


class ChatMessage(BaseModel):
    """
    聊天消息模型
    用于与OpenAI API交互
    """

    role: str = Field(..., description="消息角色：system/user/assistant")
    content: str = Field(..., description="消息内容")


class RentalQuery(BaseModel):
    """
    租房查询请求模型
    用户提交的查询请求
    """

    query: str = Field(..., description="用户查询文本")
    user_id: Optional[str] = Field(None, description="用户ID")
    session_id: Optional[str] = Field(None, description="会话ID")
    preferences: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="用户偏好设置"
    )


class RentalResponse(BaseModel):
    """
    租房查询响应模型
    返回给用户的查询结果
    """

    success: bool = Field(..., description="请求是否成功")
    query_analysis: Dict[str, Any] = Field(..., description="查询分析结果")
    recommendations: List[Recommendation] = Field(
        default_factory=list, description="推荐房源列表"
    )
    total_houses_found: int = Field(0, description="找到的房源总数")
    processing_time: float = Field(..., description="处理时间（秒）")
    token_usage: Optional[Dict[str, int]] = Field(None, description="Token使用统计")
    error_message: Optional[str] = Field(None, description="错误信息")


class APIConfig(BaseModel):
    """
    API配置模型
    管理所有外部API的配置
    """

    openai_api_key: str
    openai_model: str = "gpt-3.5-turbo-16k"
    openai_temperature: float = 0.3
    openai_max_tokens: int = 4000

    rental_api_base_url: str
    rental_api_user_id: str
    rental_api_timeout: int = 30

    cache_ttl: int = 300
    max_concurrent_requests: int = 10

    class Config:
        """Pydantic配置"""

        env_file = ".env"
        env_file_encoding = "utf-8"
