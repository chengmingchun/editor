"""
租房智能体主应用
FastAPI应用入口点，配置中间件、路由和异常处理
"""

import os
import logging
from typing import List, Dict, Any
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
import uvicorn

from .routers import rental_router

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/app.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    应用生命周期管理

    在应用启动时初始化资源，在关闭时清理资源
    """
    # 启动时
    logger.info("租房智能体应用启动中...")

    # 创建日志目录
    os.makedirs("logs", exist_ok=True)

    # 检查环境变量
    required_env_vars = ["OPENAI_API_KEY", "RENTAL_API_BASE_URL", "RENTAL_API_USER_ID"]
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]

    if missing_vars:
        logger.warning(f"缺少环境变量: {missing_vars}")
        logger.warning("应用可能无法正常工作，请检查.env文件")

    yield

    # 关闭时
    logger.info("租房智能体应用关闭中...")

    # 这里可以添加资源清理代码
    # 例如：关闭数据库连接、清理缓存等


# 创建FastAPI应用
app = FastAPI(
    title="租房智能体 API",
    description="基于FastAPI和OpenAI的智能租房推荐系统",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# 自定义OpenAPI文档
def custom_openapi():
    """
    自定义OpenAPI文档配置
    """
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="租房智能体 API",
        version="1.0.0",
        description="""
        ## 租房智能体 API
        
        一个基于FastAPI和OpenAI的智能租房推荐系统。
        
        ### 主要功能：
        
        1. **智能需求解析** - 从自然语言中提取结构化租房需求
        2. **多维度房源搜索** - 根据价格、区域、通勤等条件搜索房源
        3. **智能评分推荐** - 综合评分算法推荐最合适的房源
        4. **虚假房源排除** - 多平台验证确保房源真实性
        
        ### 使用流程：
        
        1. 发送租房查询到 `/api/v1/rental/query`
        2. 系统解析需求并搜索房源
        3. 返回5套最符合需求的房源及推荐理由
        
        ### 环境要求：
        
        - OpenAI API密钥
        - 租房数据API访问权限
        - Python 3.8+
        
        ### 示例查询：
        
        ```json
        {
          "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
          "user_id": "user123",
          "session_id": "session456"
        }
        ```
        """,
        routes=app.routes,
    )

    # 添加安全配置
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}
    }

    # 添加标签说明
    openapi_schema["tags"] = [
        {"name": "rental", "description": "租房相关接口，包括查询、统计、重置等"}
    ]

    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# 自定义文档页面
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    """
    自定义Swagger UI页面
    """
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="租房智能体 API - Swagger UI",
        swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
        swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
        swagger_favicon_url="https://fastapi.tiangolo.com/img/favicon.png",
    )


# 添加中间件
# 1. CORS中间件（允许跨域请求）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该限制来源
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. GZip压缩中间件
app.add_middleware(
    GZipMiddleware,
    minimum_size=1000,  # 只压缩大于1000字节的响应
)


# 3. 请求日志中间件
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """
    记录请求日志的中间件
    """
    logger.info(f"收到请求: {request.method} {request.url.path}")

    # 记录请求体（如果是POST/PUT请求）
    if request.method in ["POST", "PUT", "PATCH"]:
        try:
            body = await request.body()
            if body:
                logger.debug(f"请求体: {body[:500]}...")  # 只记录前500字符
        except Exception:
            pass

    # 处理请求
    response = await call_next(request)

    # 记录响应
    logger.info(f"响应状态: {response.status_code}")

    return response


# 全局异常处理
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """
    HTTP异常处理
    """
    logger.error(f"HTTP异常: {exc.status_code} - {exc.detail}")

    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": exc.detail, "status_code": exc.status_code},
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    通用异常处理
    """
    logger.error(f"未处理的异常: {exc}", exc_info=True)

    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "内部服务器错误",
            "detail": str(exc) if os.getenv("APP_DEBUG") == "true" else None,
        },
    )


# 添加路由
app.include_router(rental_router.router)


# 根路径
@app.get("/")
async def root():
    """
    根路径，返回应用信息
    """
    return {
        "message": "欢迎使用租房智能体 API",
        "version": "1.0.0",
        "docs": "/docs",
        "health_check": "/api/v1/rental/health",
        "endpoints": {
            "query": "/api/v1/rental/query",
            "stats": "/api/v1/rental/stats",
            "examples": "/api/v1/rental/examples",
        },
    }


@app.get("/info")
async def app_info():
    """
    应用信息端点
    """
    return {
        "app": "租房智能体",
        "version": "1.0.0",
        "description": "基于FastAPI和OpenAI的智能租房推荐系统",
        "author": "租房智能体团队",
        "features": [
            "智能需求解析",
            "多维度房源搜索",
            "智能评分推荐",
            "虚假房源排除",
            "多平台数据验证",
        ],
        "technology_stack": [
            "FastAPI (Web框架)",
            "OpenAI GPT (自然语言处理)",
            "Pydantic (数据验证)",
            "aiohttp (异步HTTP客户端)",
            "cachetools (缓存管理)",
        ],
    }


# 健康检查端点（兼容性）
@app.get("/health")
async def health():
    """
    健康检查（兼容旧版本）
    """
    return {"status": "healthy", "service": "rental-agent"}


# 运行应用
if __name__ == "__main__":
    # 从环境变量获取配置
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", "8000"))
    reload = os.getenv("APP_RELOAD", "true").lower() == "true"

    logger.info(f"启动租房智能体应用: http://{host}:{port}")
    logger.info(f"API文档: http://{host}:{port}/docs")
    logger.info(f"重载模式: {reload}")

    uvicorn.run("app.main:app", host=host, port=port, reload=reload, log_level="info")
