"""
租房智能体API路由
提供RESTful API接口，处理租房查询请求
"""

from typing import List, Dict, Any, Optional
from fastapi import APIRouter, HTTPException, Depends, Query, Body
from fastapi.responses import JSONResponse
import logging

from ..models import RentalQuery, RentalResponse
from ..agents.rental_agent_part2 import get_rental_agent

# 配置日志
logger = logging.getLogger(__name__)

# 创建路由器
router = APIRouter(
    prefix="/api/v1/rental",
    tags=["rental"],
    responses={
        400: {"description": "Bad Request"},
        500: {"description": "Internal Server Error"},
    },
)


@router.get("/health")
async def health_check():
    """
    健康检查端点

    返回:
        Dict: 服务状态信息
    """
    return {"status": "healthy", "service": "rental-agent", "version": "1.0.0"}


@router.post("/query", response_model=RentalResponse)
async def query_rental(
    rental_query: RentalQuery = Body(
        ...,
        example={
            "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
            "user_id": "user123",
            "session_id": "session456",
            "preferences": {"prefer_new": True, "max_commute": 40},
        },
    ),
):
    """
    处理租房查询

    参数:
        rental_query: 租房查询请求对象

    返回:
        RentalResponse: 查询响应，包含推荐房源和分析结果

    异常:
        HTTPException: 400 - 请求参数错误
        HTTPException: 500 - 服务器内部错误
    """
    try:
        logger.info(
            f"收到租房查询请求: user_id={rental_query.user_id}, query={rental_query.query[:50]}..."
        )

        # 获取智能体实例
        agent = await get_rental_agent()

        # 处理查询
        response = await agent.process_query(rental_query)

        # 记录处理结果
        if response.success:
            logger.info(
                f"查询处理成功: 找到{response.total_houses_found}套房源，推荐{len(response.recommendations)}套"
            )
        else:
            logger.warning(f"查询处理失败: {response.error_message}")

        return response

    except ValueError as e:
        logger.error(f"参数错误: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"处理查询时发生错误: {e}")
        raise HTTPException(status_code=500, detail="内部服务器错误")


@router.get("/query/text")
async def query_rental_text(
    query: str = Query(
        ..., description="用户查询文本", example="海淀区整租，预算5k以内"
    ),
    user_id: Optional[str] = Query(None, description="用户ID"),
    session_id: Optional[str] = Query(None, description="会话ID"),
):
    """
    处理租房查询（简化版，使用查询参数）

    参数:
        query: 用户查询文本
        user_id: 用户ID（可选）
        session_id: 会话ID（可选）

    返回:
        Dict: 查询响应

    异常:
        HTTPException: 400 - 请求参数错误
        HTTPException: 500 - 服务器内部错误
    """
    try:
        logger.info(f"收到简化版租房查询: query={query[:50]}...")

        # 构建查询对象
        rental_query = RentalQuery(query=query, user_id=user_id, session_id=session_id)

        # 获取智能体实例
        agent = await get_rental_agent()

        # 处理查询
        response = await agent.process_query(rental_query)

        return response.dict()

    except ValueError as e:
        logger.error(f"参数错误: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"处理查询时发生错误: {e}")
        raise HTTPException(status_code=500, detail="内部服务器错误")


@router.get("/stats")
async def get_agent_stats():
    """
    获取智能体统计信息

    返回:
        Dict: 智能体运行统计信息
    """
    try:
        agent = await get_rental_agent()
        stats = agent.get_stats()

        return {
            "success": True,
            "stats": stats,
            "timestamp": "2024-01-01T00:00:00Z",  # 实际应该使用当前时间
        }

    except Exception as e:
        logger.error(f"获取统计信息失败: {e}")
        raise HTTPException(status_code=500, detail="内部服务器错误")


@router.post("/reset")
async def reset_agent():
    """
    重置智能体状态

    注意: 这会重置房源数据和缓存，用于测试或重新开始会话

    返回:
        Dict: 重置结果
    """
    try:
        logger.info("收到重置智能体请求")

        # 重新初始化智能体
        from ..agents.rental_agent_part2 import _rental_agent

        global _rental_agent
        _rental_agent = None

        # 获取新的智能体实例（会自动初始化）
        agent = await get_rental_agent()

        return {
            "success": True,
            "message": "智能体重置成功",
            "stats": agent.get_stats(),
        }

    except Exception as e:
        logger.error(f"重置智能体失败: {e}")
        raise HTTPException(status_code=500, detail="内部服务器错误")


@router.get("/examples")
async def get_example_queries():
    """
    获取示例查询

    返回:
        List[Dict]: 示例查询列表
    """
    examples = [
        {
            "id": 1,
            "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
            "description": "海淀区整租，预算5000元以内，近地铁，西二旗通勤30分钟内",
        },
        {
            "id": 2,
            "query": "朝阳区精装修两室一厅，面积80平左右，朝南",
            "description": "朝阳区精装修两室一厅，面积80平方米左右，朝南",
        },
        {
            "id": 3,
            "query": "西二旗附近合租单间，预算2k，安静",
            "description": "西二旗附近合租单间，预算2000元，安静环境",
        },
        {
            "id": 4,
            "query": "通州整租三室，预算8k，近地铁，精装修",
            "description": "通州区整租三室，预算8000元，近地铁，精装修",
        },
        {
            "id": 5,
            "query": "望京附近整租一居室，预算6k，朝南，安静",
            "description": "望京附近整租一居室，预算6000元，朝南，安静",
        },
    ]

    return {"success": True, "examples": examples, "total": len(examples)}


@router.post("/batch")
async def batch_query(
    queries: List[str] = Body(
        ...,
        example=[
            "海淀区整租，预算5k以内",
            "朝阳区精装修两室一厅",
            "西二旗附近合租单间，预算2k",
        ],
    ),
    user_id: Optional[str] = Body(None, description="用户ID"),
    session_id: Optional[str] = Body(None, description="会话ID"),
):
    """
    批量处理租房查询

    参数:
        queries: 查询文本列表
        user_id: 用户ID（可选）
        session_id: 会话ID（可选）

    返回:
        List[RentalResponse]: 批量查询结果列表

    异常:
        HTTPException: 400 - 请求参数错误
        HTTPException: 500 - 服务器内部错误
    """
    try:
        if not queries or len(queries) > 10:
            raise ValueError("查询列表不能为空且最多10个查询")

        logger.info(f"收到批量查询请求: {len(queries)}个查询")

        # 获取智能体实例
        agent = await get_rental_agent()

        results = []
        for i, query_text in enumerate(queries):
            try:
                rental_query = RentalQuery(
                    query=query_text,
                    user_id=user_id,
                    session_id=f"{session_id}_{i}" if session_id else None,
                )

                response = await agent.process_query(rental_query)
                results.append(response.dict())

                logger.info(f"批量查询进度: {i + 1}/{len(queries)}")

            except Exception as e:
                logger.warning(f"处理查询失败: {query_text[:50]}..., 错误: {e}")
                results.append(
                    {"success": False, "error_message": str(e), "query": query_text}
                )

        return {
            "success": True,
            "total": len(queries),
            "processed": len([r for r in results if r.get("success", False)]),
            "failed": len([r for r in results if not r.get("success", True)]),
            "results": results,
        }

    except ValueError as e:
        logger.error(f"参数错误: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"批量处理查询时发生错误: {e}")
        raise HTTPException(status_code=500, detail="内部服务器错误")


# 错误处理
@router.get("/error-test")
async def error_test():
    """
    错误测试端点（仅用于测试）

    返回:
        HTTPException: 500 - 测试错误
    """
    raise HTTPException(status_code=500, detail="这是一个测试错误")


# 中间件示例（可以在这里添加认证、限流等中间件）
def validate_user_id(user_id: Optional[str] = Query(None)):
    """
    用户ID验证中间件

    参数:
        user_id: 用户ID

    返回:
        str: 验证后的用户ID

    异常:
        HTTPException: 401 - 未授权
    """
    if user_id and len(user_id) < 3:
        raise HTTPException(status_code=401, detail="用户ID无效")
    return user_id or "anonymous"
