"""
租房API客户端模块
封装与租房数据API的交互，实现所有15个接口的调用
"""

import asyncio
import time
import json
from typing import List, Dict, Any, Optional, Union
from datetime import datetime
import logging
import aiohttp
from aiohttp import ClientSession, ClientTimeout
import cachetools

from ..models import (
    Landmark,
    House,
    HouseListing,
    SearchResult,
    LandmarkCategory,
    ListingPlatform,
    HouseStatus,
)

# 配置日志
logger = logging.getLogger(__name__)


class RentalAPIClient:
    """
    租房API客户端类
    负责与租房数据API的交互，包括房源查询、地标查询、租房操作等
    """

    def __init__(
        self,
        base_url: str,
        user_id: str,
        timeout: int = 30,
        max_retries: int = 3,
        cache_ttl: int = 300,
    ):
        """
        初始化API客户端

        Args:
            base_url: API基础URL
            user_id: 用户ID（比赛工号）
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
            cache_ttl: 缓存时间（秒）
        """
        self.base_url = base_url.rstrip("/")
        self.user_id = user_id
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache_ttl = cache_ttl

        # 创建缓存（LRU缓存，最大1000个条目）
        self.cache = cachetools.TTLCache(maxsize=1000, ttl=cache_ttl)

        # 创建aiohttp会话
        self.session: Optional[ClientSession] = None
        self.timeout_obj = ClientTimeout(total=timeout)

        # 请求头
        self.headers = {"Content-Type": "application/json", "X-User-ID": user_id}

        # API端点映射
        self.endpoints = {
            # 地标相关接口（不需要X-User-ID）
            "landmarks_list": "/api/landmarks",
            "landmark_by_name": "/api/landmarks/name/{name}",
            "landmark_search": "/api/landmarks/search",
            "landmark_by_id": "/api/landmarks/{id}",
            "landmark_stats": "/api/landmarks/stats",
            # 房源相关接口（需要X-User-ID）
            "house_by_id": "/api/houses/{house_id}",
            "house_listings": "/api/houses/listings/{house_id}",
            "houses_by_community": "/api/houses/by_community",
            "houses_by_platform": "/api/houses/by_platform",
            "houses_nearby": "/api/houses/nearby",
            "nearby_landmarks": "/api/houses/nearby_landmarks",
            "house_stats": "/api/houses/stats",
            # 操作接口（需要X-User-ID）
            "rent_house": "/api/houses/{house_id}/rent",
            "terminate_rent": "/api/houses/{house_id}/terminate",
            "offline_house": "/api/houses/{house_id}/offline",
            # 数据重置接口
            "reset_data": "/api/houses/init",
        }

    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.close()

    async def connect(self):
        """创建aiohttp会话"""
        if self.session is None or self.session.closed:
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=20)
            self.session = ClientSession(
                connector=connector, timeout=self.timeout_obj, headers=self.headers
            )
            logger.info("API客户端连接已建立")

    async def close(self):
        """关闭aiohttp会话"""
        if self.session and not self.session.closed:
            await self.session.close()
            logger.info("API客户端连接已关闭")

    def _get_cache_key(self, method: str, endpoint: str, params: Dict = None) -> str:
        """
        生成缓存键

        Args:
            method: HTTP方法
            endpoint: API端点
            params: 请求参数

        Returns:
            str: 缓存键
        """
        key_parts = [method, endpoint]
        if params:
            # 对参数排序以确保一致性
            sorted_params = sorted(params.items())
            key_parts.append(str(sorted_params))
        return ":".join(key_parts)

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        require_user_id: bool = True,
        use_cache: bool = True,
    ) -> Dict[str, Any]:
        """
        发送HTTP请求

        Args:
            method: HTTP方法（GET/POST等）
            endpoint: API端点
            params: 查询参数
            data: 请求体数据
            require_user_id: 是否需要X-User-ID头
            use_cache: 是否使用缓存

        Returns:
            Dict[str, Any]: API响应数据

        Raises:
            Exception: 请求失败
        """
        # 确保会话已连接
        await self.connect()

        # 构建完整URL
        url = f"{self.base_url}{endpoint}"

        # 生成缓存键（仅对GET请求缓存）
        cache_key = None
        if method.upper() == "GET" and use_cache:
            cache_key = self._get_cache_key(method, endpoint, params)
            if cache_key in self.cache:
                logger.debug(f"缓存命中: {cache_key}")
                return self.cache[cache_key]

        # 准备请求头
        headers = self.headers.copy() if require_user_id else {}
        if not require_user_id:
            headers.pop("X-User-ID", None)

        # 重试逻辑
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                start_time = time.time()

                async with self.session.request(
                    method=method, url=url, params=params, json=data, headers=headers
                ) as response:
                    response_time = time.time() - start_time

                    # 检查HTTP状态码
                    if response.status >= 400:
                        error_text = await response.text()
                        logger.warning(
                            f"API请求失败: {method} {url} - "
                            f"状态码: {response.status}, 响应: {error_text[:200]}"
                        )

                        # 如果是400错误且包含用户ID问题，可能是配置错误
                        if response.status == 400 and "X-User-ID" in error_text:
                            raise ValueError(f"用户ID配置错误: {self.user_id}")

                        # 如果是429（限流），等待后重试
                        if response.status == 429 and attempt < self.max_retries - 1:
                            wait_time = 2**attempt  # 指数退避
                            logger.info(f"被限流，等待{wait_time}秒后重试")
                            await asyncio.sleep(wait_time)
                            continue

                        response.raise_for_status()

                    # 解析响应
                    result = await response.json()

                    # 记录请求日志
                    logger.debug(
                        f"API请求成功: {method} {url} - "
                        f"耗时: {response_time:.2f}s, 状态码: {response.status}"
                    )

                    # 缓存GET请求结果
                    if cache_key and method.upper() == "GET":
                        self.cache[cache_key] = result

                    return result

            except asyncio.TimeoutError:
                last_exception = TimeoutError(f"请求超时: {method} {url}")
                logger.warning(f"请求超时，尝试 {attempt + 1}/{self.max_retries}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(1)  # 等待1秒后重试
            except aiohttp.ClientError as e:
                last_exception = e
                logger.warning(
                    f"客户端错误: {e}, 尝试 {attempt + 1}/{self.max_retries}"
                )
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(1)
            except Exception as e:
                last_exception = e
                logger.error(f"请求异常: {e}")
                break

        # 所有重试都失败
        raise Exception(f"API请求失败: {method} {url}") from last_exception

    async def reset_house_data(self) -> bool:
        """
        重置房源数据

        在每个会话开始时调用，确保使用初始化的数据

        Returns:
            bool: 是否重置成功
        """
        try:
            logger.info("正在重置房源数据...")
            response = await self._make_request(
                method="POST",
                endpoint=self.endpoints["reset_data"],
                use_cache=False,  # 不缓存重置请求
            )
            success = response.get("success", False)
            if success:
                logger.info("房源数据重置成功")
                # 清空缓存，因为数据已更新
                self.cache.clear()
            else:
                logger.warning("房源数据重置失败")
            return success
        except Exception as e:
            logger.error(f"房源数据重置异常: {e}")
            return False

    # ========== 地标相关接口 ==========

    async def get_landmarks(
        self,
        category: Optional[LandmarkCategory] = None,
        district: Optional[str] = None,
    ) -> List[Landmark]:
        """
        获取地标列表

        Args:
            category: 地标类别筛选
            district: 行政区筛选

        Returns:
            List[Landmark]: 地标列表
        """
        params = {}
        if category:
            params["category"] = category.value
        if district:
            params["district"] = district

        response = await self._make_request(
            method="GET",
            endpoint=self.endpoints["landmarks_list"],
            params=params,
            require_user_id=False,
        )

        data = response.get("data", [])
        return [Landmark(**item) for item in data]

    async def get_landmark_by_name(self, name: str) -> Optional[Landmark]:
        """
        按名称精确查询地标

        Args:
            name: 地标名称

        Returns:
            Optional[Landmark]: 地标信息，如果不存在则返回None
        """
        try:
            endpoint = self.endpoints["landmark_by_name"].format(name=name)
            response = await self._make_request(
                method="GET", endpoint=endpoint, require_user_id=False
            )

            data = response.get("data")
            return Landmark(**data) if data else None
        except Exception as e:
            logger.warning(f"查询地标失败: {name}, 错误: {e}")
            return None

    async def search_landmarks(
        self,
        keyword: str,
        category: Optional[LandmarkCategory] = None,
        district: Optional[str] = None,
    ) -> List[Landmark]:
        """
        关键词模糊搜索地标

        Args:
            keyword: 搜索关键词
            category: 地标类别筛选
            district: 行政区筛选

        Returns:
            List[Landmark]: 搜索结果列表
        """
        params = {"keyword": keyword}
        if category:
            params["category"] = category.value
        if district:
            params["district"] = district

        response = await self._make_request(
            method="GET",
            endpoint=self.endpoints["landmark_search"],
            params=params,
            require_user_id=False,
        )

        data = response.get("data", [])
        return [Landmark(**item) for item in data]

    async def get_landmark_by_id(self, landmark_id: str) -> Optional[Landmark]:
        """
        按ID查询地标详情

        Args:
            landmark_id: 地标ID

        Returns:
            Optional[Landmark]: 地标信息
        """
        try:
            endpoint = self.endpoints["landmark_by_id"].format(id=landmark_id)
            response = await self._make_request(
                method="GET", endpoint=endpoint, require_user_id=False
            )

            data = response.get("data")
            return Landmark(**data) if data else None
        except Exception as e:
            logger.warning(f"查询地标详情失败: {landmark_id}, 错误: {e}")
            return None

    async def get_landmark_stats(self) -> Dict[str, Any]:
        """
        获取地标统计信息

        Returns:
            Dict[str, Any]: 统计信息
        """
        response = await self._make_request(
            method="GET",
            endpoint=self.endpoints["landmark_stats"],
            require_user_id=False,
        )
        return response.get("data", {})

    # ========== 房源相关接口 ==========

    async def get_house_by_id(self, house_id: str) -> Optional[House]:
        """
        根据房源ID获取单套房源详情

        Args:
            house_id: 房源ID

        Returns:
            Optional[House]: 房源信息
        """
        try:
            endpoint = self.endpoints["house_by_id"].format(house_id=house_id)
            response = await self._make_request(method="GET", endpoint=endpoint)

            data = response.get("data")
            return House(**data) if data else None
        except Exception as e:
            logger.warning(f"查询房源详情失败: {house_id}, 错误: {e}")
            return None

    async def get_house_listings(self, house_id: str) -> List[HouseListing]:
        """
        获取房源在各平台的挂牌记录

        Args:
            house_id: 房源ID

        Returns:
            List[HouseListing]: 挂牌记录列表
        """
        try:
            endpoint = self.endpoints["house_listings"].format(house_id=house_id)
            response = await self._make_request(method="GET", endpoint=endpoint)

            data = response.get("data", {})
            items = data.get("items", [])
            return [HouseListing(**item) for item in items]
        except Exception as e:
            logger.warning(f"查询房源挂牌记录失败: {house_id}, 错误: {e}")
            return []

    async def get_houses_by_community(
        self,
        community: str,
        page: int = 1,
        page_size: int = 10,
        platform: Optional[ListingPlatform] = None,
    ) -> SearchResult:
        """
        按小区名查询可租房源

        Args:
            community: 小区名称
            page: 页码
            page_size: 每页大小
            platform: 挂牌平台筛选

        Returns:
            SearchResult: 搜索结果
        """
        params = {"community": community, "page": page, "page_size": page_size}
        if platform:
            params["listing_platform"] = platform.value

        response = await self._make_request(
            method="GET", endpoint=self.endpoints["houses_by_community"], params=params
        )

        data = response.get("data", {})
        houses = [House(**item) for item in data.get("items", [])]

        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    async def get_houses_by_platform(
        self,
        platform: Optional[ListingPlatform] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> SearchResult:
        """
        按挂牌平台查询可租房源

        Args:
            platform: 挂牌平台
            page: 页码
            page_size: 每页大小

        Returns:
            SearchResult: 搜索结果
        """
        params = {"page": page, "page_size": page_size}
        if platform:
            params["listing_platform"] = platform.value

        response = await self._make_request(
            method="GET", endpoint=self.endpoints["houses_by_platform"], params=params
        )

        data = response.get("data", {})
        houses = [House(**item) for item in data.get("items", [])]

        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    async def get_houses_nearby(
        self,
        landmark_id: str,
        max_distance: int = 2000,
        page: int = 1,
        page_size: int = 10,
        platform: Optional[ListingPlatform] = None,
    ) -> SearchResult:
        """
        以地标为圆心查询附近房源

        Args:
            landmark_id: 地标ID
            max_distance: 最大距离（米）
            page: 页码
            page_size: 每页大小
            platform: 挂牌平台筛选

        Returns:
            SearchResult: 搜索结果
        """
        params = {
            "landmark_id": landmark_id,
            "max_distance": max_distance,
            "page": page,
            "page_size": page_size,
        }
        if platform:
            params["listing_platform"] = platform.value

        response = await self._make_request(
            method="GET", endpoint=self.endpoints["houses_nearby"], params=params
        )

        data = response.get("data", {})
        houses = [House(**item) for item in data.get("items", [])]

        return SearchResult(
            houses=houses,
            total=data.get("total", 0),
            page=data.get("page", 1),
            page_size=data.get("page_size", 10),
        )

    async def get_nearby_landmarks(
        self, community: str, category: LandmarkCategory, max_distance: int = 3000
    ) -> List[Landmark]:
        """
        查询小区周边某类地标

        Args:
            community: 小区名称
            category: 地标类别
            max_distance: 最大距离（米）

        Returns:
            List[Landmark]: 附近地标列表
        """
        params = {
            "community": community,
            "category": category.value,
            "max_distance_m": max_distance,
        }

        response = await self._make_request(
            method="GET", endpoint=self.endpoints["nearby_landmarks"], params=params
        )

        data = response.get("data", [])
        return [Landmark(**item) for item in data]

    async def get_house_stats(self) -> Dict[str, Any]:
        """
        获取房源统计信息

        Returns:
            Dict[str, Any]: 统计信息
        """
        response = await self._make_request(
            method="GET", endpoint=self.endpoints["house_stats"]
        )
        return response.get("data", {})

    # ========== 操作接口 ==========

    async def rent_house(self, house_id: str, platform: ListingPlatform) -> bool:
        """
        租房操作

        Args:
            house_id: 房源ID
            platform: 挂牌平台

        Returns:
            bool: 操作是否成功
        """
        try:
            endpoint = self.endpoints["rent_house"].format(house_id=house_id)
            data = {"listing_platform": platform.value}

            response = await self._make_request(
                method="POST",
                endpoint=endpoint,
                data=data,
                use_cache=False,  # 操作请求不缓存
            )

            success = response.get("success", False)
            if success:
                logger.info(f"租房操作成功: {house_id} on {platform.value}")
                # 清空相关缓存
                self._invalidate_house_cache(house_id)
            return success
        except Exception as e:
            logger.error(f"租房操作失败: {house_id}, 错误: {e}")
            return False

    async def terminate_rent(self, house_id: str, platform: ListingPlatform) -> bool:
        """
        退租操作

        Args:
            house_id: 房源ID
            platform: 挂牌平台

        Returns:
            bool: 操作是否成功
        """
        try:
            endpoint = self.endpoints["terminate_rent"].format(house_id=house_id)
            data = {"listing_platform": platform.value}

            response = await self._make_request(
                method="POST", endpoint=endpoint, data=data, use_cache=False
            )

            success = response.get("success", False)
            if success:
                logger.info(f"退租操作成功: {house_id} on {platform.value}")
                self._invalidate_house_cache(house_id)
            return success
        except Exception as e:
            logger.error(f"退租操作失败: {house_id}, 错误: {e}")
            return False

    async def offline_house(self, house_id: str, platform: ListingPlatform) -> bool:
        """
        下架房源操作

        Args:
            house_id: 房源ID
            platform: 挂牌平台

        Returns:
            bool: 操作是否成功
        """
        try:
            endpoint = self.endpoints["offline_house"].format(house_id=house_id)
            data = {"listing_platform": platform.value}

            response = await self._make_request(
                method="POST", endpoint=endpoint, data=data, use_cache=False
            )

            success = response.get("success", False)
            if success:
                logger.info(f"下架操作成功: {house_id} on {platform.value}")
                self._invalidate_house_cache(house_id)
            return success
        except Exception as e:
            logger.error(f"下架操作失败: {house_id}, 错误: {e}")
            return False

    def _invalidate_house_cache(self, house_id: str):
        """
        使房源相关缓存失效

        Args:
            house_id: 房源ID
        """
        # 这里可以更精细地清除特定房源的缓存
        # 目前简单清除所有缓存
        self.cache.clear()
        logger.debug(f"已清除缓存（房源操作: {house_id}）")

    # ========== 批量操作和高级查询 ==========

    async def batch_get_houses(self, house_ids: List[str]) -> List[House]:
        """
        批量获取房源详情

        Args:
            house_ids: 房源ID列表

        Returns:
            List[House]: 房源列表
        """
        tasks = [self.get_house_by_id(house_id) for house_id in house_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        houses = []
        for result in results:
            if isinstance(result, House):
                houses.append(result)
            elif isinstance(result, Exception):
                logger.warning(f"批量获取房源失败: {result}")

        return houses

    async def search_houses_by_requirements(
        self, requirement: Dict[str, Any], max_results: int = 100
    ) -> List[House]:
        """
        根据需求条件搜索房源

        Args:
            requirement: 需求条件字典
            max_results: 最大结果数

        Returns:
            List[House]: 符合条件的房源列表
        """
        # 这里实现智能搜索逻辑
        # 1. 根据目标地标搜索
        # 2. 根据行政区搜索
        # 3. 综合筛选

        all_houses = []

        # 根据目标地标搜索
        target_landmarks = requirement.get("target_landmarks")
        if target_landmarks:
            for landmark_name in target_landmarks[:2]:  # 最多搜索2个地标
                landmark = await self.get_landmark_by_name(landmark_name)
                if landmark:
                    result = await self.get_houses_nearby(
                        landmark_id=landmark.id, max_distance=2000, page_size=50
                    )
                    all_houses.extend(result.houses)

        # 根据行政区搜索
        districts = requirement.get("districts")
        if districts and len(all_houses) < max_results // 2:
            for district in districts[:2]:  # 最多搜索2个行政区
                landmarks = await self.get_landmarks(district=district)
                for landmark in landmarks[:3]:  # 每个行政区最多3个地标
                    result = await self.get_houses_nearby(
                        landmark_id=landmark.id, max_distance=3000, page_size=30
                    )
                    all_houses.extend(result.houses)

        # 如果还没有足够结果，进行通用搜索
        if not all_houses:
            result = await self.get_houses_by_platform(page_size=100)
            all_houses = result.houses

        # 去重
        unique_houses = {}
        for house in all_houses:
            if house.id not in unique_houses and house.status.value == "可租":
                unique_houses[house.id] = house

        return list(unique_houses.values())[:max_results]


# 创建全局API客户端实例
_rental_client: Optional[RentalAPIClient] = None


async def get_rental_client() -> RentalAPIClient:
    """
    获取租房API客户端实例（单例模式）

    Returns:
        RentalAPIClient: API客户端实例
    """
    global _rental_client
    if _rental_client is None:
        import os
        from dotenv import load_dotenv

        load_dotenv()

        base_url = os.getenv("RENTAL_API_BASE_URL", "http://localhost:8080")
        user_id = os.getenv("RENTAL_API_USER_ID", "test_user")
        timeout = int(os.getenv("RENTAL_API_TIMEOUT", "30"))
        cache_ttl = int(os.getenv("CACHE_TTL", "300"))

        _rental_client = RentalAPIClient(
            base_url=base_url, user_id=user_id, timeout=timeout, cache_ttl=cache_ttl
        )
        await _rental_client.connect()

    return _rental_client
