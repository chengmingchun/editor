"""
OpenAI服务模块
封装与OpenAI API的交互，提供智能需求解析和文本生成功能
"""

import asyncio
import json
from typing import List, Dict, Any, Optional, Union
from datetime import datetime
import logging

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam

from ..models import (
    UserRequirement,
    ChatMessage,
    RentalQuery,
    HouseType,
    Decoration,
    Orientation,
    NoiseLevel,
)

# 配置日志
logger = logging.getLogger(__name__)


class OpenAIService:
    """
    OpenAI服务类
    负责与OpenAI API的交互，包括需求解析、文本生成、智能分析等
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-3.5-turbo-16k",
        temperature: float = 0.3,
        max_tokens: int = 4000,
    ):
        """
        初始化OpenAI服务

        Args:
            api_key: OpenAI API密钥
            model: 使用的模型名称，默认使用16k版本处理长文本
            temperature: 温度参数，控制输出的随机性（0-1）
            max_tokens: 最大输出token数
        """
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

        # 系统提示词模板
        self.system_prompt = """你是一个专业的租房需求分析专家。你的任务是从用户的自然语言描述中提取结构化的租房需求。

请严格按照以下JSON格式输出，不要添加任何额外的解释：

{
  "max_price": 整数或null,  // 最高预算（元），如5000表示5k以内
  "min_price": 整数或null,  // 最低预算（元）
  "districts": ["行政区1", "行政区2"]或null,  // 目标行政区
  "house_type": "entire"或"shared"或null,  // 房屋类型：entire=整租，shared=合租
  "layout": "户型"或null,  // 如"2室"、"3室1厅"等
  "min_area": 浮点数或null,  // 最小面积（平方米）
  "max_area": 浮点数或null,  // 最大面积（平方米）
  "max_subway_distance": 整数或null,  // 最大地铁距离（米），近地铁=800
  "max_commute_time": 整数或null,  // 最大通勤时间（分钟）
  "target_landmarks": ["地标1", "地标2"]或null,  // 目标地标，如西二旗、国贸
  "decoration": "简装/精装/豪华/毛坯/空房"或null,  // 装修要求
  "orientation": "朝南/朝北/朝东/朝西/南北/东西"或null,  // 朝向要求
  "min_bathrooms": 整数或null,  // 最少卫生间数量
  "noise_level": "安静/中等/吵闹/临街"或null,  // 噪音要求
  "tags": ["标签1", "标签2"]或null,  // 特殊标签要求
  "available_date": "YYYY-MM-DD"或null  // 可入住日期
}

提取规则：
1. 价格：识别"5k"、"5000元"、"预算5k以内"等表达
2. 区域：识别"海淀区"、"朝阳或者通州"等
3. 户型：识别"两室一厅"、"三居室"等
4. 通勤：识别"近地铁"、"地铁口"、"到西二旗30分钟"等
5. 装修：识别"精装修"、"简装"等
6. 朝向：识别"朝南"、"南北通透"等
7. 噪音：识别"安静"、"不临街"等
8. 日期：识别"立即入住"、"下个月"等

如果没有明确提到某项，请设置为null。"""

        # 推荐理由生成提示词
        self.recommendation_prompt = """你是一个专业的租房顾问。请根据以下房源信息和用户需求，生成3-5条推荐理由。

房源信息：
{house_info}

用户需求：
{user_requirement}

匹配度评分：{score}/100

请生成简洁、具体、有说服力的推荐理由，每条理由不超过20个字。格式如下：
1. 理由1
2. 理由2
3. 理由3

重点关注：
- 价格性价比
- 地理位置优势
- 通勤便利性
- 房屋条件（装修、朝向、面积等）
- 周边配套
- 特殊优势（如多平台验证、稀缺户型等）"""

        # AI分析总结提示词
        self.analysis_prompt = """你是一个资深的房产分析师。请对以下租房推荐结果进行智能分析总结。

用户原始查询：{user_query}

需求分析结果：{requirement_analysis}

推荐房源概况：{recommendations_summary}

请从以下角度进行分析：
1. 市场匹配度：用户需求在当前市场的满足程度
2. 价格合理性：推荐房源的价格是否合理
3. 地理位置优势：推荐区域的特点和优势
4. 潜在风险：需要注意的问题或风险
5. 优化建议：如果当前推荐不理想，如何调整需求

分析要求：
- 语言简洁专业
- 提供具体数据支持
- 给出实用建议
- 不超过300字"""

    async def parse_requirement(self, query_text: str) -> UserRequirement:
        """
        解析用户自然语言查询为结构化需求

        Args:
            query_text: 用户查询文本

        Returns:
            UserRequirement: 结构化的用户需求

        Raises:
            Exception: OpenAI API调用失败或解析错误
        """
        try:
            logger.info(f"开始解析用户需求: {query_text[:50]}...")

            # 构建消息列表
            messages: List[ChatCompletionMessageParam] = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"用户查询：{query_text}"},
            ]

            # 调用OpenAI API
            start_time = datetime.now()
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                response_format={"type": "json_object"},  # 强制JSON格式输出
            )
            processing_time = (datetime.now() - start_time).total_seconds()

            # 解析响应
            content = response.choices[0].message.content
            if not content:
                raise ValueError("OpenAI返回空内容")

            # 解析JSON
            try:
                parsed_data = json.loads(content)
            except json.JSONDecodeError as e:
                logger.error(f"JSON解析失败: {e}, 原始内容: {content}")
                # 尝试提取JSON部分
                import re

                json_match = re.search(r"\{.*\}", content, re.DOTALL)
                if json_match:
                    parsed_data = json.loads(json_match.group())
                else:
                    raise ValueError(f"无法解析JSON: {content}")

            # 转换为UserRequirement对象
            requirement = UserRequirement(**parsed_data)

            logger.info(f"需求解析完成，耗时{processing_time:.2f}秒")
            logger.debug(f"解析结果: {requirement.dict(exclude_none=True)}")

            return requirement

        except Exception as e:
            logger.error(f"需求解析失败: {e}")
            raise

    async def generate_recommendation_reasons(
        self, house_info: Dict[str, Any], user_requirement: Dict[str, Any], score: float
    ) -> List[str]:
        """
        生成房源推荐理由

        Args:
            house_info: 房源信息字典
            user_requirement: 用户需求字典
            score: 匹配度评分

        Returns:
            List[str]: 推荐理由列表
        """
        try:
            # 准备提示词
            prompt = self.recommendation_prompt.format(
                house_info=json.dumps(house_info, ensure_ascii=False, indent=2),
                user_requirement=json.dumps(
                    user_requirement, ensure_ascii=False, indent=2
                ),
                score=score,
            )

            messages: List[ChatCompletionMessageParam] = [
                {
                    "role": "system",
                    "content": "你是一个专业的租房顾问，擅长生成简洁有力的推荐理由。",
                },
                {"role": "user", "content": prompt},
            ]

            # 调用OpenAI API
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.5,  # 稍高的温度使输出更有创造性
                max_tokens=500,
            )

            content = response.choices[0].message.content
            if not content:
                return ["房源匹配用户需求"]

            # 解析推荐理由（按行分割，去除序号）
            reasons = []
            for line in content.strip().split("\n"):
                line = line.strip()
                # 移除数字序号和标点
                if line and any(c.isdigit() for c in line[:3]):
                    # 提取序号后的内容
                    reason = line.split(".", 1)[-1].strip()
                    if reason:
                        reasons.append(reason)
                elif line and len(line) > 5:  # 短行可能是格式问题
                    reasons.append(line)

            # 如果没有解析出理由，使用默认理由
            if not reasons:
                reasons = [
                    f"匹配度评分{score:.1f}，符合主要需求",
                    "价格在预算范围内",
                    "地理位置便利",
                ]

            return reasons[:5]  # 最多返回5条理由

        except Exception as e:
            logger.error(f"生成推荐理由失败: {e}")
            return ["房源经过系统筛选，符合用户基本需求"]

    async def generate_analysis_summary(
        self,
        user_query: str,
        requirement_analysis: Dict[str, Any],
        recommendations_summary: str,
    ) -> str:
        """
        生成智能分析总结

        Args:
            user_query: 用户原始查询
            requirement_analysis: 需求分析结果
            recommendations_summary: 推荐房源概况

        Returns:
            str: 分析总结文本
        """
        try:
            prompt = self.analysis_prompt.format(
                user_query=user_query,
                requirement_analysis=json.dumps(
                    requirement_analysis, ensure_ascii=False, indent=2
                ),
                recommendations_summary=recommendations_summary,
            )

            messages: List[ChatCompletionMessageParam] = [
                {
                    "role": "system",
                    "content": "你是一个资深的房产分析师，擅长从专业角度分析租房市场。",
                },
                {"role": "user", "content": prompt},
            ]

            response = await self.client.chat.completions.create(
                model=self.model, messages=messages, temperature=0.4, max_tokens=800
            )

            content = response.choices[0].message.content
            return content or "暂无分析数据"

        except Exception as e:
            logger.error(f"生成分析总结失败: {e}")
            return "分析服务暂时不可用"

    async def extract_keywords(self, text: str) -> List[str]:
        """
        从文本中提取关键词

        Args:
            text: 输入文本

        Returns:
            List[str]: 关键词列表
        """
        try:
            prompt = f"""从以下租房相关文本中提取关键词，每个关键词用逗号分隔：
            
文本：{text}

请提取：
1. 地理位置关键词（行政区、商圈、地标）
2. 房屋特征关键词（户型、面积、装修等）
3. 价格预算关键词
4. 通勤相关关键词
5. 其他重要关键词

只返回关键词，用中文逗号分隔，不要解释。"""

            messages: List[ChatCompletionMessageParam] = [
                {
                    "role": "system",
                    "content": "你是一个关键词提取专家，擅长从文本中提取核心信息。",
                },
                {"role": "user", "content": prompt},
            ]

            response = await self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                temperature=0.1,  # 低温度确保稳定性
                max_tokens=200,
            )

            content = response.choices[0].message.content
            if content:
                # 分割关键词，清理空白
                keywords = [k.strip() for k in content.split(",") if k.strip()]
                return keywords

            return []

        except Exception as e:
            logger.error(f"关键词提取失败: {e}")
            return []

    async def optimize_search_query(
        self, requirement: UserRequirement
    ) -> Dict[str, Any]:
        """
        优化搜索查询参数

        Args:
            requirement: 用户需求

        Returns:
            Dict[str, Any]: 优化后的搜索参数
        """
        try:
            # 将需求转换为文本描述
            req_text = json.dumps(
                requirement.dict(exclude_none=True), ensure_ascii=False
            )

            prompt = f"""根据以下租房需求，生成最优的搜索策略：

用户需求：{req_text}

请考虑：
1. 哪些条件应该优先满足（硬性条件）
2. 哪些条件可以适当放宽（软性条件）
3. 搜索范围应该如何确定
4. 如何平衡搜索效率和结果质量

返回JSON格式：
{{
  "priority_conditions": ["条件1", "条件2"],
  "flexible_conditions": ["条件1", "条件2"],
  "search_strategy": "策略描述",
  "optimization_tips": ["提示1", "提示2"]
}}"""

            messages: List[ChatCompletionMessageParam] = [
                {
                    "role": "system",
                    "content": "你是一个搜索优化专家，擅长制定高效的搜索策略。",
                },
                {"role": "user", "content": prompt},
            ]

            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.2,
                max_tokens=500,
                response_format={"type": "json_object"},
            )

            content = response.choices[0].message.content
            if content:
                return json.loads(content)

            return {}

        except Exception as e:
            logger.error(f"搜索查询优化失败: {e}")
            return {}

    def get_token_usage(self) -> Dict[str, int]:
        """
        获取token使用统计（模拟）

        在实际应用中，可以从OpenAI响应中获取真实的token使用
        """
        return {"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500}


# 创建全局OpenAI服务实例
_openai_service: Optional[OpenAIService] = None


def get_openai_service() -> OpenAIService:
    """
    获取OpenAI服务实例（单例模式）

    Returns:
        OpenAIService: OpenAI服务实例
    """
    global _openai_service
    if _openai_service is None:
        # 从环境变量或配置文件中读取API密钥
        import os
        from dotenv import load_dotenv

        load_dotenv()

        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY环境变量未设置")

        model = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo-16k")
        temperature = float(os.getenv("OPENAI_TEMPERATURE", "0.3"))
        max_tokens = int(os.getenv("OPENAI_MAX_TOKENS", "4000"))

        _openai_service = OpenAIService(
            api_key=api_key, model=model, temperature=temperature, max_tokens=max_tokens
        )

    return _openai_service
