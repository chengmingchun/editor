"""
API测试模块
测试租房智能体API的功能和性能
"""

import pytest
import asyncio
import json
from typing import Dict, Any, List
from httpx import AsyncClient
from app.main import app


class TestRentalAgentAPI:
    """租房智能体API测试类"""

    @pytest.fixture
    async def client(self):
        """创建测试客户端"""
        async with AsyncClient(app=app, base_url="http://test") as client:
            yield client

    @pytest.mark.asyncio
    async def test_health_check(self, client):
        """测试健康检查端点"""
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "service" in data
        assert "version" in data

    @pytest.mark.asyncio
    async def test_root_endpoint(self, client):
        """测试根端点"""
        response = await client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "version" in data
        assert "docs" in data
        assert "endpoints" in data

    @pytest.mark.asyncio
    async def test_app_info(self, client):
        """测试应用信息端点"""
        response = await client.get("/info")
        assert response.status_code == 200
        data = response.json()
        assert data["app"] == "租房智能体"
        assert "version" in data
        assert "description" in data
        assert "features" in data
        assert "technology_stack" in data

    @pytest.mark.asyncio
    async def test_rental_health(self, client):
        """测试租房健康检查"""
        response = await client.get("/api/v1/rental/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["service"] == "rental-agent"

    @pytest.mark.asyncio
    async def test_examples_endpoint(self, client):
        """测试示例查询端点"""
        response = await client.get("/api/v1/rental/examples")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "examples" in data
        assert "total" in data
        assert isinstance(data["examples"], list)
        assert len(data["examples"]) > 0

        # 检查示例结构
        example = data["examples"][0]
        assert "id" in example
        assert "query" in example
        assert "description" in example

    @pytest.mark.asyncio
    async def test_stats_endpoint(self, client):
        """测试统计信息端点"""
        response = await client.get("/api/v1/rental/stats")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "stats" in data
        assert "timestamp" in data

        stats = data["stats"]
        assert "total_queries" in stats
        assert "avg_processing_time" in stats
        assert "success_rate" in stats

    @pytest.mark.asyncio
    async def test_query_endpoint_basic(self, client):
        """测试基本查询端点"""
        query_data = {
            "query": "测试查询",
            "user_id": "test_user_001",
            "session_id": "test_session_001",
        }

        response = await client.post("/api/v1/rental/query", json=query_data)

        # 由于是测试环境，可能返回错误或降级响应
        # 我们主要测试API端点是否正常工作
        assert response.status_code in [200, 400, 500]

        if response.status_code == 200:
            data = response.json()
            assert "success" in data
            assert "query_analysis" in data
            assert "recommendations" in data
            assert "total_houses_found" in data
            assert "processing_time" in data

    @pytest.mark.asyncio
    async def test_query_text_endpoint(self, client):
        """测试简化版查询端点"""
        response = await client.get(
            "/api/v1/rental/query/text",
            params={"query": "测试查询", "user_id": "test_user"},
        )

        # 检查响应状态
        assert response.status_code in [200, 400, 500]

        if response.status_code == 200:
            data = response.json()
            assert "success" in data
            # 其他字段检查取决于实际实现

    @pytest.mark.asyncio
    async def test_batch_query_endpoint(self, client):
        """测试批量查询端点"""
        batch_data = {
            "queries": [
                "海淀区整租，预算5k以内",
                "朝阳区精装修两室一厅",
                "西二旗附近合租单间，预算2k",
            ],
            "user_id": "test_user_001",
            "session_id": "batch_test_001",
        }

        response = await client.post("/api/v1/rental/batch", json=batch_data)

        # 检查响应状态
        assert response.status_code in [200, 400, 500]

        if response.status_code == 200:
            data = response.json()
            assert data["success"] is True
            assert "total" in data
            assert "processed" in data
            assert "failed" in data
            assert "results" in data
            assert isinstance(data["results"], list)
            assert len(data["results"]) == len(batch_data["queries"])

    @pytest.mark.asyncio
    async def test_reset_endpoint(self, client):
        """测试重置端点"""
        response = await client.post("/api/v1/rental/reset")

        # 检查响应状态
        assert response.status_code in [200, 500]

        if response.status_code == 200:
            data = response.json()
            assert data["success"] is True
            assert "message" in data
            assert "stats" in data

    @pytest.mark.asyncio
    async def test_error_handling(self, client):
        """测试错误处理"""
        # 测试无效查询
        invalid_data = {
            "query": "",  # 空查询
            "user_id": "test",
        }

        response = await client.post("/api/v1/rental/query", json=invalid_data)
        # 可能返回400或500，取决于实现
        assert response.status_code >= 400

        # 测试批量查询超出限制
        too_many_queries = {
            "queries": ["测试"] * 15,  # 超过10个查询
            "user_id": "test",
        }

        response = await client.post("/api/v1/rental/batch", json=too_many_queries)
        assert response.status_code in [400, 500]

    @pytest.mark.asyncio
    async def test_query_structure(self, client):
        """测试查询响应结构"""
        # 使用一个合理的测试查询
        query_data = {"query": "海淀区整租", "user_id": "structure_test"}

        response = await client.post("/api/v1/rental/query", json=query_data)

        if response.status_code == 200:
            data = response.json()

            # 检查基本结构
            assert isinstance(data, dict)
            assert "success" in data
            assert isinstance(data["success"], bool)

            if data["success"]:
                # 成功响应的结构检查
                assert "query_analysis" in data
                assert isinstance(data["query_analysis"], dict)

                assert "recommendations" in data
                assert isinstance(data["recommendations"], list)

                assert "total_houses_found" in data
                assert isinstance(data["total_houses_found"], int)
                assert data["total_houses_found"] >= 0

                assert "processing_time" in data
                assert isinstance(data["processing_time"], (int, float))
                assert data["processing_time"] >= 0

                # 检查推荐项结构
                if data["recommendations"]:
                    recommendation = data["recommendations"][0]
                    assert "house" in recommendation
                    assert "score" in recommendation
                    assert "reasons" in recommendation
                    assert "listings" in recommendation

                    # 检查房源结构
                    house = recommendation["house"]
                    required_house_fields = [
                        "id",
                        "address",
                        "district",
                        "community",
                        "house_type",
                        "layout",
                        "area",
                        "price",
                    ]
                    for field in required_house_fields:
                        assert field in house

    @pytest.mark.asyncio
    async def test_concurrent_requests(self, client):
        """测试并发请求"""
        # 创建多个并发请求
        queries = [
            {"query": f"测试查询{i}", "user_id": f"concurrent_user_{i}"}
            for i in range(3)
        ]

        # 并发发送请求
        tasks = [
            client.post("/api/v1/rental/query", json=query_data)
            for query_data in queries
        ]

        responses = await asyncio.gather(*tasks)

        # 检查所有请求都得到响应
        assert len(responses) == len(queries)

        for response in responses:
            # 每个请求都应该有响应
            assert response.status_code in [200, 400, 500]

    @pytest.mark.asyncio
    async def test_preferences_handling(self, client):
        """测试偏好设置处理"""
        query_data = {
            "query": "测试带偏好的查询",
            "user_id": "pref_test_user",
            "preferences": {
                "prefer_new": True,
                "max_commute": 40,
                "min_area": 60,
                "require_elevator": True,
            },
        }

        response = await client.post("/api/v1/rental/query", json=query_data)

        # 检查API是否接受偏好设置
        assert response.status_code in [200, 400, 500]

        if response.status_code == 200:
            data = response.json()
            # API应该能够处理偏好设置，即使不全部使用
            assert "success" in data


class TestPerformance:
    """性能测试类"""

    @pytest.mark.asyncio
    async def test_response_time(self, client):
        """测试响应时间"""
        import time

        query_data = {"query": "性能测试查询", "user_id": "perf_test_user"}

        start_time = time.time()
        response = await client.post("/api/v1/rental/query", json=query_data)
        end_time = time.time()

        response_time = end_time - start_time

        # 记录响应时间
        print(f"API响应时间: {response_time:.2f}秒")

        # 响应应该在合理时间内完成
        # 这里设置一个宽松的上限（30秒）
        assert response_time < 30, f"响应时间过长: {response_time:.2f}秒"

        # 检查响应状态
        assert response.status_code in [200, 400, 500]

    @pytest.mark.asyncio
    async def test_memory_usage(self):
        """测试内存使用（概念性测试）"""
        # 这是一个概念性测试，实际内存测试需要更复杂的工具
        import psutil
        import os

        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB

        # 执行一些操作后检查内存
        # 这里只是示例，实际测试需要具体操作

        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory

        print(f"内存使用变化: {memory_increase:.2f} MB")

        # 内存增加应该在合理范围内
        # 这个阈值需要根据实际情况调整
        assert memory_increase < 100, f"内存增加过多: {memory_increase:.2f} MB"


class TestIntegration:
    """集成测试类"""

    @pytest.mark.asyncio
    async def test_full_workflow(self, client):
        """测试完整工作流程"""
        # 1. 检查服务状态
        health_response = await client.get("/health")
        assert health_response.status_code == 200

        # 2. 获取示例查询
        examples_response = await client.get("/api/v1/rental/examples")
        assert examples_response.status_code == 200
        examples_data = examples_response.json()

        if examples_data["examples"]:
            # 3. 使用示例查询进行测试
            example_query = examples_data["examples"][0]["query"]

            query_data = {"query": example_query, "user_id": "integration_test_user"}

            # 4. 发送查询
            query_response = await client.post("/api/v1/rental/query", json=query_data)
            assert query_response.status_code in [200, 400, 500]

            if query_response.status_code == 200:
                query_result = query_response.json()

                # 5. 检查查询结果
                if query_result["success"]:
                    # 6. 获取统计信息
                    stats_response = await client.get("/api/v1/rental/stats")
                    assert stats_response.status_code == 200

                    stats_data = stats_response.json()
                    assert stats_data["success"] is True

                    # 7. 验证统计信息更新
                    # 这里可以添加更详细的验证逻辑

                    print("完整工作流程测试通过")

    @pytest.mark.asyncio
    async def test_error_workflow(self, client):
        """测试错误处理工作流程"""
        # 1. 发送无效查询
        invalid_query = {
            "query": "",  # 空查询
            "user_id": "error_test_user",
        }

        response = await client.post("/api/v1/rental/query", json=invalid_query)

        # 2. 检查错误响应
        if response.status_code == 400:
            error_data = response.json()
            assert error_data["success"] is False
            assert "error" in error_data
            assert "status_code" in error_data

            print(f"错误处理测试通过: {error_data['error']}")
        else:
            # API可能以其他方式处理空查询
            print(f"API以状态码 {response.status_code} 处理空查询")


# 运行测试的辅助函数
def run_tests():
    """运行所有测试"""
    import sys
    import pytest

    # 添加测试参数
    test_args = [
        "tests/test_api.py",
        "-v",  # 详细输出
        "--tb=short",  # 简短的错误回溯
        "-x",  # 遇到第一个失败时停止
        # "--cov=app",  # 覆盖率报告（需要pytest-cov）
        # "--cov-report=term-missing"
    ]

    # 运行测试
    exit_code = pytest.main(test_args)
    sys.exit(exit_code)


if __name__ == "__main__":
    run_tests()
