# 租房智能体 API 文档

## 概述

租房智能体是一个基于FastAPI和OpenAI的智能租房推荐系统，能够理解自然语言需求，搜索匹配房源，并提供个性化推荐。

## 基础信息

- **基础URL**: `http://localhost:8000`
- **API版本**: `v1`
- **数据格式**: JSON
- **认证**: 目前无需认证（生产环境建议添加）

## 快速开始

### 1. 安装和运行

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑.env文件，设置必要的配置

# 3. 运行应用
python -m app.main

# 或者使用uvicorn直接运行
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2. 测试连接

```bash
# 健康检查
curl http://localhost:8000/health

# 应用信息
curl http://localhost:8000/info
```

## API端点

### 根路径

#### GET /
**描述**: 返回应用基本信息

**响应**:
```json
{
  "message": "欢迎使用租房智能体 API",
  "version": "1.0.0",
  "docs": "/docs",
  "health_check": "/api/v1/rental/health",
  "endpoints": {
    "query": "/api/v1/rental/query",
    "stats": "/api/v1/rental/stats",
    "examples": "/api/v1/rental/examples"
  }
}
```

### 健康检查

#### GET /api/v1/rental/health
**描述**: 检查服务健康状态

**响应**:
```json
{
  "status": "healthy",
  "service": "rental-agent",
  "version": "1.0.0"
}
```

### 租房查询

#### POST /api/v1/rental/query
**描述**: 处理租房查询请求

**请求体**:
```json
{
  "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
  "user_id": "user123",
  "session_id": "session456",
  "preferences": {
    "prefer_new": true,
    "max_commute": 40
  }
}
```

**参数说明**:
- `query`: **必需**，用户查询文本
- `user_id`: 可选，用户标识
- `session_id`: 可选，会话标识
- `preferences`: 可选，用户偏好设置

**响应**:
```json
{
  "success": true,
  "query_analysis": {
    "max_price": 5000,
    "districts": ["海淀"],
    "house_type": "entire",
    "max_subway_distance": 800,
    "max_commute_time": 30
  },
  "recommendations": [
    {
      "house": {
        "id": "house_123",
        "address": "北京市海淀区中关村大街1号",
        "district": "海淀",
        "community": "中关村小区",
        "house_type": "entire",
        "layout": "2室1厅1卫",
        "area": 85.0,
        "price": 4800,
        "subway_station": "中关村站",
        "subway_distance": 350,
        "xierqi_commute": 25,
        "decoration": "精装",
        "orientation": "朝南",
        "bathrooms": 1,
        "noise_level": "安静",
        "tags": ["近地铁", "精装修", "朝南"],
        "status": "可租"
      },
      "score": 92.5,
      "reasons": [
        "价格4800元在预算范围内",
        "距地铁仅350米，非常便利",
        "西二旗通勤25分钟，符合要求",
        "精装修朝南，居住舒适"
      ],
      "listings": [
        {
          "platform": "安居客",
          "house_id": "house_123",
          "price": 4800,
          "status": "可租",
          "posted_at": "2024-01-15"
        }
      ],
      "ai_analysis": "该房源性价比高，地理位置优越..."
    }
  ],
  "total_houses_found": 45,
  "processing_time": 2.34,
  "token_usage": {
    "prompt_tokens": 1200,
    "completion_tokens": 450,
    "total_tokens": 1650
  }
}
```

#### GET /api/v1/rental/query/text
**描述**: 简化版租房查询（使用查询参数）

**参数**:
- `query`: **必需**，用户查询文本
- `user_id`: 可选，用户标识
- `session_id`: 可选，会话标识

**示例**:
```bash
curl "http://localhost:8000/api/v1/rental/query/text?query=海淀区整租，预算5k以内&user_id=test123"
```

### 批量查询

#### POST /api/v1/rental/batch
**描述**: 批量处理租房查询

**请求体**:
```json
{
  "queries": [
    "海淀区整租，预算5k以内",
    "朝阳区精装修两室一厅",
    "西二旗附近合租单间，预算2k"
  ],
  "user_id": "user123",
  "session_id": "batch_001"
}
```

**响应**:
```json
{
  "success": true,
  "total": 3,
  "processed": 3,
  "failed": 0,
  "results": [
    {
      "success": true,
      "query_analysis": {...},
      "recommendations": [...],
      "total_houses_found": 45,
      "processing_time": 2.1
    },
    // ... 其他查询结果
  ]
}
```

### 统计信息

#### GET /api/v1/rental/stats
**描述**: 获取智能体运行统计信息

**响应**:
```json
{
  "success": true,
  "stats": {
    "total_queries": 150,
    "avg_processing_time": 2.5,
    "success_rate": 98.7,
    "success_count": 148,
    "openai_service": {
      "prompt_tokens": 120000,
      "completion_tokens": 45000,
      "total_tokens": 165000
    }
  },
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### 示例查询

#### GET /api/v1/rental/examples
**描述**: 获取示例查询列表

**响应**:
```json
{
  "success": true,
  "examples": [
    {
      "id": 1,
      "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
      "description": "海淀区整租，预算5000元以内，近地铁，西二旗通勤30分钟内"
    },
    {
      "id": 2,
      "query": "朝阳区精装修两室一厅，面积80平左右，朝南",
      "description": "朝阳区精装修两室一厅，面积80平方米左右，朝南"
    }
  ],
  "total": 5
}
```

### 重置智能体

#### POST /api/v1/rental/reset
**描述**: 重置智能体状态（清除缓存，重新初始化）

**响应**:
```json
{
  "success": true,
  "message": "智能体重置成功",
  "stats": {
    "total_queries": 0,
    "avg_processing_time": 0,
    "success_rate": 0
  }
}
```

## 数据模型

### RentalQuery（租房查询请求）
```python
{
  "query": "string",          # 用户查询文本
  "user_id": "string",        # 用户ID（可选）
  "session_id": "string",     # 会话ID（可选）
  "preferences": {            # 用户偏好（可选）
    "prefer_new": boolean,
    "max_commute": integer,
    "other_preferences": any
  }
}
```

### RentalResponse（租房查询响应）
```python
{
  "success": boolean,         # 是否成功
  "query_analysis": {         # 查询分析结果
    "max_price": integer,
    "min_price": integer,
    "districts": ["string"],
    "house_type": "entire|shared",
    "layout": "string",
    "min_area": float,
    "max_area": float,
    "max_subway_distance": integer,
    "max_commute_time": integer,
    "target_landmarks": ["string"],
    "decoration": "简装|精装|豪华|毛坯|空房",
    "orientation": "朝南|朝北|朝东|朝西|南北|东西",
    "min_bathrooms": integer,
    "noise_level": "安静|中等|吵闹|临街",
    "tags": ["string"],
    "available_date": "string"
  },
  "recommendations": [        # 推荐房源列表
    Recommendation
  ],
  "total_houses_found": integer,  # 找到的房源总数
  "processing_time": float,   # 处理时间（秒）
  "token_usage": {           # Token使用统计（可选）
    "prompt_tokens": integer,
    "completion_tokens": integer,
    "total_tokens": integer
  },
  "error_message": "string"   # 错误信息（失败时）
}
```

### Recommendation（推荐结果）
```python
{
  "house": House,            # 房源信息
  "score": float,            # 匹配度评分（0-100）
  "reasons": ["string"],     # 推荐理由列表
  "listings": [              # 多平台挂牌信息
    HouseListing
  ],
  "ai_analysis": "string"    # AI分析总结（可选）
}
```

### House（房源信息）
```python
{
  "id": "string",            # 房源唯一ID
  "address": "string",       # 详细地址
  "district": "string",      # 所在行政区
  "community": "string",     # 小区名称
  "house_type": "entire|shared",  # 房屋类型
  "layout": "string",        # 户型描述
  "area": float,             # 面积（平方米）
  "price": integer,          # 月租金（元）
  "available_date": "string", # 可入住日期
  "floor": "string",         # 楼层信息
  "subway_station": "string", # 最近地铁站
  "subway_distance": integer, # 到地铁站距离（米）
  "xierqi_commute": integer, # 到西二旗通勤时间（分钟）
  "decoration": "简装|精装|豪华|毛坯|空房",  # 装修等级
  "orientation": "朝南|朝北|朝东|朝西|南北|东西",  # 朝向
  "bathrooms": integer,      # 卫生间数量
  "noise_level": "安静|中等|吵闹|临街",  # 噪音水平
  "tags": ["string"],        # 房源标签
  "status": "可租|已租|下架", # 房源状态
  "latitude": float,         # 纬度
  "longitude": float         # 经度
}
```

### HouseListing（房源挂牌记录）
```python
{
  "platform": "安居客|链家|58同城",  # 挂牌平台
  "house_id": "string",      # 房源ID
  "price": integer,          # 挂牌价格
  "status": "可租|已租|下架", # 挂牌状态
  "posted_at": "string"      # 挂牌时间
}
```

## 错误处理

### 错误响应格式
```json
{
  "success": false,
  "error": "错误描述",
  "status_code": 400,
  "detail": "详细错误信息（调试模式）"
}
```

### 常见错误码
- `400 Bad Request`: 请求参数错误
- `401 Unauthorized`: 未授权访问
- `404 Not Found`: 资源不存在
- `429 Too Many Requests`: 请求过于频繁
- `500 Internal Server Error`: 服务器内部错误
- `503 Service Unavailable`: 服务暂时不可用

## 使用示例

### Python客户端示例
```python
import requests
import json

class RentalAgentClient:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
    
    def query_rental(self, query_text, user_id=None):
        """发送租房查询"""
        url = f"{self.base_url}/api/v1/rental/query"
        payload = {
            "query": query_text,
            "user_id": user_id
        }
        
        response = requests.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    
    def batch_query(self, queries, user_id=None):
        """批量查询"""
        url = f"{self.base_url}/api/v1/rental/batch"
        payload = {
            "queries": queries,
            "user_id": user_id
        }
        
        response = requests.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    
    def get_stats(self):
        """获取统计信息"""
        url = f"{self.base_url}/api/v1/rental/stats"
        response = requests.get(url)
        response.raise_for_status()
        return response.json()

# 使用示例
client = RentalAgentClient()

# 单次查询
result = client.query_rental(
    query_text="海淀区整租，预算5k以内",
    user_id="test_user_001"
)
print(f"找到房源: {result['total_houses_found']}套")
print(f"推荐房源: {len(result['recommendations'])}套")

# 批量查询
queries = [
    "海淀区整租，预算5k以内",
    "朝阳区精装修两室一厅",
    "西二旗附近合租单间，预算2k"
]
batch_result = client.batch_query(queries, user_id="test_user_001")
print(f"批量处理完成: {batch_result['processed']}/{batch_result['total']}")

# 获取统计
stats = client.get_stats()
print(f"总查询次数: {stats['stats']['total_queries']}")
print(f"平均处理时间: {stats['stats']['avg_processing_time']:.2f}秒")
```

### cURL示例
```bash
# 健康检查
curl http://localhost:8000/health

# 单次查询
curl -X POST http://localhost:8000/api/v1/rental/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "海淀区整租，预算5k以内",
    "user_id": "test123"
  }'

# 简化版查询
curl "http://localhost:8000/api/v1/rental/query/text?query=海淀区整租，预算5k以内&user_id=test123"

# 批量查询
curl -X POST http://localhost:8000/api/v1/rental/batch \
  -H "Content-Type: application/json" \
  -d '{
    "queries": [
      "海淀区整租，预算5k以内",
      "朝阳区精装修两室一厅"
    ],
    "user_id": "test123"
  }'

# 获取统计
curl http://localhost:8000/api/v1/rental/stats

# 获取示例
curl http://localhost:8000/api/v1/rental/examples

# 重置智能体
curl -X POST http://localhost:8000/api/v1/rental/reset
```

## 最佳实践

### 1. 查询优化
- 使用具体的需求描述（如"海淀区整租"而不是"租房"）
- 明确预算范围（如"预算5k以内"）
- 指定关键要求（如"近地铁"、"朝南"）
- 合理使用通勤时间要求

### 2. 错误处理
- 检查响应中的`success`字段
- 处理HTTP错误状态码
- 实现重试机制（对于临时错误）
- 记录错误信息用于调试

### 3. 性能考虑
- 批量处理多个查询（使用`/batch`端点）
- 缓存频繁查询的结果
- 监控API调用频率和Token使用
- 设置合理的超时时间

### 4. 数据使用
- 尊重用户隐私，妥善处理用户数据
- 遵守数据使用政策和服务条款
- 定期清理过期数据
- 备份重要数据

## 限制和配额

### 1. 请求限制
- 单次查询最大房源数：100套
- 批量查询最大查询数：10个
- 建议查询频率：≤ 10次/分钟

### 2. Token限制
- 每次查询最大Token使用：4000
- 建议监控Token使用情况
- 超出限制可能导致查询失败

### 3. 数据限制
- 支持北京11个行政区
- 价格范围：500-25000元/月
- 面积范围：12-145平方米
- 通勤时间：8-95分钟

## 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 支持自然语言租房查询
- 实现智能需求解析
- 提供个性化房源推荐
- 包含批量查询和统计功能

## 支持

如有问题或建议，请：
1. 查看API文档和示例
2. 检查错误信息和日志
3. 联系技术支持团队
4. 提交GitHub Issue

---

**注意**: 本文档基于当前版本（v1.0.0），API可能会随着版本更新而变化。建议定期查看最新文档。