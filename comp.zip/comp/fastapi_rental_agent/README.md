# 🏡 租房智能体 (FastAPI + OpenAI)

一个基于FastAPI和OpenAI的智能租房推荐系统，能够理解自然语言需求，搜索匹配房源，并提供个性化推荐。

## ✨ 核心特性

### 🧠 智能需求解析
- **自然语言理解**: 使用OpenAI GPT解析用户模糊需求
- **混合解析策略**: 规则匹配 + AI深度解析
- **结构化输出**: 提取价格、区域、户型、通勤等结构化需求

### 🔍 多维度房源搜索
- **15个API接口**: 完整支持比赛要求的全部接口
- **智能搜索策略**: 根据地标、行政区、通用搜索分层处理
- **虚假房源排除**: 多平台数据交叉验证

### 📊 智能评分推荐
- **综合评分算法**: 7个维度加权评分（价格25%、位置20%、通勤15%等）
- **个性化推荐**: 输出5套最符合需求的房源
- **详细推荐理由**: AI生成 + 规则生成的混合理由

### ⚡ 高性能优化
- **异步处理**: 全异步架构，支持高并发
- **智能缓存**: 多级缓存策略，减少API调用
- **Token优化**: 最小化OpenAI API使用成本
- **错误恢复**: 优雅降级和重试机制

## 🏗️ 系统架构

```
fastapi_rental_agent/
├── app/                          # 应用代码
│   ├── models/                  # 数据模型（Pydantic）
│   │   └── __init__.py          # 所有数据模型定义
│   ├── services/                # 服务层
│   │   ├── openai_service.py    # OpenAI集成服务
│   │   └── rental_api_client.py # 租房API客户端（15个接口）
│   ├── agents/                  # 智能体核心
│   │   ├── rental_agent_part1.py # 需求解析器
│   │   └── rental_agent_part2.py # 评分器和主智能体
│   ├── routers/                 # API路由
│   │   └── rental_router.py     # 租房相关路由
│   ├── utils/                   # 工具函数
│   └── main.py                  # FastAPI主应用
├── tests/                       # 测试代码
│   └── test_api.py              # API测试
├── docs/                        # 文档
│   ├── API_DOCUMENTATION.md     # API详细文档
│   └── OPTIMIZATION_TIPS.md     # 优化技巧说明
├── config/                      # 配置文件
├── logs/                        # 日志目录（自动创建）
├── requirements.txt             # Python依赖
├── .env.example                 # 环境变量示例
└── README.md                    # 项目说明
```

## 🚀 快速开始

### 1. 环境准备
```bash
# 克隆项目
git clone <repository-url>
cd fastapi_rental_agent

# 创建虚拟环境（推荐）
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或 venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 2. 配置设置
```bash
# 复制环境变量文件
cp .env.example .env

# 编辑.env文件，设置以下关键配置：
# OPENAI_API_KEY=你的OpenAI API密钥
# RENTAL_API_BASE_URL=租房API基础URL
# RENTAL_API_USER_ID=比赛用户工号
```

### 3. 运行应用
```bash
# 方式1：直接运行
python -m app.main

# 方式2：使用uvicorn
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# 方式3：生产环境运行
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### 4. 访问应用
- 应用主页: http://localhost:8000
- API文档: http://localhost:8000/docs
- 健康检查: http://localhost:8000/health

## 📖 API使用示例

### 基本查询
```python
import requests

# 单次查询
response = requests.post(
    "http://localhost:8000/api/v1/rental/query",
    json={
        "query": "海淀区整租，预算5k以内，近地铁，到西二旗30分钟通勤",
        "user_id": "test_user_001"
    }
)

result = response.json()
print(f"找到房源: {result['total_houses_found']}套")
print(f"推荐房源: {len(result['recommendations'])}套")

# 查看推荐详情
for i, rec in enumerate(result['recommendations'][:3]):
    house = rec['house']
    print(f"{i+1}. {house['community']} - {house['layout']} - {house['price']}元/月")
    print(f"   评分: {rec['score']:.1f}, 理由: {', '.join(rec['reasons'][:2])}")
```

### 批量查询
```python
# 批量查询
batch_response = requests.post(
    "http://localhost:8000/api/v1/rental/batch",
    json={
        "queries": [
            "海淀区整租，预算5k以内",
            "朝阳区精装修两室一厅",
            "西二旗附近合租单间，预算2k"
        ],
        "user_id": "batch_user_001"
    }
)

batch_result = batch_response.json()
print(f"批量处理完成: {batch_result['processed']}/{batch_result['total']}")
```

### cURL示例
```bash
# 健康检查
curl http://localhost:8000/health

# 单次查询
curl -X POST http://localhost:8000/api/v1/rental/query \
  -H "Content-Type: application/json" \
  -d '{"query": "海淀区整租，预算5k以内", "user_id": "test123"}'

# 获取统计
curl http://localhost:8000/api/v1/rental/stats

# 获取示例
curl http://localhost:8000/api/v1/rental/examples
```

## 🔧 配置说明

### 环境变量
```env
# OpenAI配置
OPENAI_API_KEY=sk-...                    # OpenAI API密钥
OPENAI_MODEL=gpt-3.5-turbo-16k          # 使用16k版本处理长文本
OPENAI_TEMPERATURE=0.3                   # 输出稳定性控制
OPENAI_MAX_TOKENS=4000                   # 最大输出token数

# 租房API配置
RENTAL_API_BASE_URL=http://localhost:8080  # 租房API基础URL
RENTAL_API_USER_ID=your_user_id           # 比赛用户工号（必须正确）
RENTAL_API_TIMEOUT=30                     # API超时时间

# FastAPI配置
APP_HOST=0.0.0.0                         # 监听地址
APP_PORT=8000                            # 监听端口
APP_DEBUG=true                           # 调试模式
APP_RELOAD=true                          # 热重载

# 缓存配置
CACHE_TTL=300                            # 缓存时间（秒）
MAX_CONCURRENT_REQUESTS=10               # 最大并发请求数
```

### 评分权重配置
```python
# 在HouseScorer类中配置
self.weights = {
    "price": 0.25,       # 价格最重要（25%）
    "location": 0.20,    # 位置次重要（20%）
    "commute": 0.15,     # 通勤重要（15%）
    "condition": 0.15,   # 房屋条件（15%）
    "tags": 0.10,        # 标签优势（10%）
    "platforms": 0.10,   # 平台验证（10%）
    "ai_extra": 0.05     # AI额外评分（5%）
}
```

## 🧪 测试

### 运行测试
```bash
# 安装测试依赖
pip install pytest pytest-asyncio httpx

# 运行所有测试
pytest tests/ -v

# 运行特定测试
pytest tests/test_api.py::TestRentalAgentAPI::test_health_check -v

# 带覆盖率报告
pytest tests/ --cov=app --cov-report=term-missing
```

### 测试覆盖
- ✅ API端点测试
- ✅ 错误处理测试
- ✅ 并发请求测试
- ✅ 性能测试
- ✅ 集成测试

## 📈 性能优化

### Token使用优化
1. **模型选择**: 使用gpt-3.5-turbo-16k处理长文本
2. **提示词优化**: 结构化输出，明确格式要求
3. **温度控制**: 不同任务使用不同temperature值
4. **本地处理**: 能用规则处理的不用AI

### API调用优化
1. **智能缓存**: GET请求缓存300秒
2. **批量请求**: 并行获取多个房源信息
3. **重试机制**: 指数退避重试策略
4. **超时控制**: 合理设置超时时间

### 搜索优化
1. **分层搜索**: 根据地标→行政区→通用的优先级
2. **结果去重**: 基于房源ID去重
3. **智能过滤**: 硬性条件快速过滤
4. **评分排序**: 综合评分算法排序

## 🛠️ 开发指南

### 添加新功能
1. **扩展数据模型**: 在`app/models/__init__.py`中添加新模型
2. **添加API端点**: 在`app/routers/rental_router.py`中添加新路由
3. **实现业务逻辑**: 在`app/agents/`中添加新的智能体组件
4. **添加测试**: 在`tests/`中添加对应的测试用例

### 代码结构规范
```python
# 1. 使用类型注解
def process_query(query: str) -> Dict[str, Any]:
    """函数说明"""
    pass

# 2. 添加文档字符串
class RentalAgent:
    """类说明"""
    
    def method(self, param: str) -> str:
        """方法说明
        
        Args:
            param: 参数说明
            
        Returns:
            返回值说明
            
        Raises:
            ExceptionType: 异常说明
        """
        pass

# 3. 错误处理
try:
    result = await some_async_call()
except SpecificError as e:
    logger.error(f"错误详情: {e}")
    raise HTTPException(status_code=400, detail="用户友好错误信息")
except Exception as e:
    logger.error(f"未预期错误: {e}", exc_info=True)
    raise HTTPException(status_code=500, detail="内部服务器错误")
```

## 📚 详细文档

- [API详细文档](docs/API_DOCUMENTATION.md) - 完整的API接口说明
- [优化技巧说明](docs/OPTIMIZATION_TIPS.md) - 性能优化和最佳实践
- [测试文档](tests/test_api.py) - 测试用例和测试方法

## 🎯 比赛注意事项

### 关键要求
1. **用户工号**: 必须正确设置`RENTAL_API_USER_ID`，否则用例执行会冲突
2. **数据重置**: 每个session开始时自动调用数据重置接口
3. **请求头**: 所有房源相关接口自动添加`X-User-ID`请求头
4. **近地铁定义**: 800米以内视为近地铁，1000米以内视为地铁可达

### 性能目标
- **响应时间**: < 5秒（典型查询）
- **Token使用**: 最小化OpenAI API调用
- **API调用**: 减少不必要的租房API调用
- **内存使用**: 优化数据结构，减少内存占用

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🙏 致谢

- [FastAPI](https://fastapi.tiangolo.com/) - 现代、快速的Web框架
- [OpenAI](https://openai.com/) - 提供强大的语言模型API
- [Pydantic](https://pydantic-docs.helpmanual.io/) - 数据验证和设置管理
- 所有贡献者和用户

## 📞 支持

如有问题或建议，请：
1. 查看 [API文档](docs/API_DOCUMENTATION.md)
2. 检查 [优化技巧](docs/OPTIMIZATION_TIPS.md)
3. 提交GitHub Issue
4. 联系维护团队

---

**Happy House Hunting! 🏠✨**