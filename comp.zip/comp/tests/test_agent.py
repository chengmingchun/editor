import unittest
from unittest.mock import Mock, patch
from src.agents.rental_agent import RequirementParser, HouseScorer, RentalAgent
from src.models import (
    UserRequirement,
    House,
    HouseType,
    Decoration,
    Orientation,
    NoiseLevel,
)


class TestRequirementParser(unittest.TestCase):
    def setUp(self):
        self.parser = RequirementParser()

    def test_parse_price(self):
        text = "预算5k以内"
        req = self.parser.parse_text(text)
        self.assertEqual(req.max_price, 5000)

        text = "3k到8k"
        req = self.parser.parse_text(text)
        self.assertEqual(req.min_price, 3000)
        self.assertEqual(req.max_price, 8000)

    def test_parse_district(self):
        text = "海淀区租房"
        req = self.parser.parse_text(text)
        self.assertIn("海淀", req.districts)

        text = "朝阳或者通州"
        req = self.parser.parse_text(text)
        self.assertIn("朝阳", req.districts)
        self.assertIn("通州", req.districts)

    def test_parse_house_type(self):
        text = "整租一套房"
        req = self.parser.parse_text(text)
        self.assertEqual(req.house_type, HouseType.ENTIRE)

        text = "合租单间"
        req = self.parser.parse_text(text)
        self.assertEqual(req.house_type, HouseType.SHARED)

    def test_parse_layout(self):
        text = "两室一厅"
        req = self.parser.parse_text(text)
        self.assertEqual(req.layout, "2室")

        text = "三居室"
        req = self.parser.parse_text(text)
        self.assertEqual(req.layout, "3室")

    def test_parse_subway(self):
        text = "近地铁"
        req = self.parser.parse_text(text)
        self.assertEqual(req.max_subway_distance, 800)

    def test_parse_commute(self):
        text = "到西二旗30分钟通勤"
        req = self.parser.parse_text(text)
        self.assertEqual(req.max_commute_time, 30)

    def test_parse_decoration(self):
        text = "精装修"
        req = self.parser.parse_text(text)
        self.assertEqual(req.decoration, Decoration.FINE)

    def test_parse_orientation(self):
        text = "朝南"
        req = self.parser.parse_text(text)
        self.assertEqual(req.orientation, Orientation.SOUTH)

    def test_parse_noise(self):
        text = "安静"
        req = self.parser.parse_text(text)
        self.assertEqual(req.noise_level, NoiseLevel.QUIET)


class TestHouseScorer(unittest.TestCase):
    def setUp(self):
        self.scorer = HouseScorer()
        self.house = House(
            id="test123",
            address="测试地址",
            district="海淀",
            community="测试小区",
            house_type=HouseType.ENTIRE,
            layout="2室1厅1卫",
            area=80.0,
            price=5000,
            available_date="2024-01-01",
            floor="10/20",
            subway_station="测试地铁站",
            subway_distance=500,
            xierqi_commute=25,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            bathrooms=1,
            noise_level=NoiseLevel.QUIET,
            tags=["近地铁", "精装修", "朝南"],
            status="可租",
            latitude=39.9,
            longitude=116.3,
        )

    def test_score_perfect_match(self):
        req = UserRequirement(
            max_price=6000,
            districts=["海淀"],
            house_type=HouseType.ENTIRE,
            layout="2室",
            max_subway_distance=800,
            max_commute_time=30,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            noise_level=NoiseLevel.QUIET,
        )

        score, reasons = self.scorer.calculate_score(self.house, req)
        self.assertGreater(score, 80)
        self.assertIn("价格5000元符合预算", reasons)
        self.assertIn("位于海淀区", reasons)

    def test_score_price_too_high(self):
        req = UserRequirement(max_price=4000)
        score, reasons = self.scorer.calculate_score(self.house, req)
        self.assertLess(score, 80)
        self.assertIn("价格5000元超出预算", reasons)

    def test_score_wrong_district(self):
        req = UserRequirement(districts=["朝阳"])
        score, reasons = self.scorer.calculate_score(self.house, req)
        self.assertLess(score, 80)
        self.assertIn("区域海淀不符合要求", reasons)

    def test_score_subway_too_far(self):
        house = self.house.copy()
        house.subway_distance = 1500

        req = UserRequirement(max_subway_distance=800)
        score, reasons = self.scorer.calculate_score(house, req)
        self.assertLess(score, 80)
        self.assertIn("距地铁1500米较远", reasons)

    def test_score_positive_tags(self):
        house = self.house.copy()
        house.tags = ["近地铁", "精装修", "朝南", "有电梯", "采光好"]

        req = UserRequirement()
        score, reasons = self.scorer.calculate_score(house, req)
        self.assertGreater(score, 100)

    def test_score_negative_tags(self):
        house = self.house.copy()
        house.tags = ["临街", "毛坯", "农村房"]

        req = UserRequirement()
        score, reasons = self.scorer.calculate_score(house, req)
        self.assertLess(score, 100)


class TestRentalAgent(unittest.TestCase):
    def setUp(self):
        self.agent = RentalAgent()
        self.agent.api_client = Mock()

    def test_initialize_session(self):
        self.agent.api_client.reset_house_data.return_value = True
        self.agent.initialize_session()
        self.agent.api_client.reset_house_data.assert_called_once()

    @patch.object(RentalAgent, "_filter_house")
    def test_search_houses_with_landmarks(self, mock_filter):
        mock_filter.return_value = True

        landmark_mock = Mock()
        landmark_mock.id = "landmark123"
        self.agent.api_client.get_landmark_by_name.return_value = landmark_mock

        house_mock = Mock()
        house_mock.id = "house123"
        house_mock.status.value = "可租"

        result_mock = Mock()
        result_mock.houses = [house_mock]
        self.agent.api_client.get_houses_nearby.return_value = result_mock

        req = UserRequirement(target_landmarks=["西二旗"])
        houses = self.agent.search_houses(req)

        self.assertEqual(len(houses), 1)
        self.agent.api_client.get_landmark_by_name.assert_called_with("西二旗")
        self.agent.api_client.get_houses_nearby.assert_called()

    def test_filter_house_basic(self):
        house = House(
            id="test123",
            address="测试地址",
            district="海淀",
            community="测试小区",
            house_type=HouseType.ENTIRE,
            layout="2室1厅1卫",
            area=80.0,
            price=5000,
            available_date="2024-01-01",
            floor="10/20",
            subway_station="测试地铁站",
            subway_distance=500,
            xierqi_commute=25,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            bathrooms=1,
            noise_level=NoiseLevel.QUIET,
            tags=[],
            status="可租",
            latitude=39.9,
            longitude=116.3,
        )

        req = UserRequirement(
            max_price=6000, districts=["海淀"], house_type=HouseType.ENTIRE
        )

        result = self.agent._filter_house(house, req)
        self.assertTrue(result)

    def test_filter_house_price_too_high(self):
        house = House(
            id="test123",
            address="测试地址",
            district="海淀",
            community="测试小区",
            house_type=HouseType.ENTIRE,
            layout="2室1厅1卫",
            area=80.0,
            price=7000,
            available_date="2024-01-01",
            floor="10/20",
            subway_station="测试地铁站",
            subway_distance=500,
            xierqi_commute=25,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            bathrooms=1,
            noise_level=NoiseLevel.QUIET,
            tags=[],
            status="可租",
            latitude=39.9,
            longitude=116.3,
        )

        req = UserRequirement(max_price=6000)
        result = self.agent._filter_house(house, req)
        self.assertFalse(result)

    def test_filter_house_wrong_district(self):
        house = House(
            id="test123",
            address="测试地址",
            district="朝阳",
            community="测试小区",
            house_type=HouseType.ENTIRE,
            layout="2室1厅1卫",
            area=80.0,
            price=5000,
            available_date="2024-01-01",
            floor="10/20",
            subway_station="测试地铁站",
            subway_distance=500,
            xierqi_commute=25,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            bathrooms=1,
            noise_level=NoiseLevel.QUIET,
            tags=[],
            status="可租",
            latitude=39.9,
            longitude=116.3,
        )

        req = UserRequirement(districts=["海淀"])
        result = self.agent._filter_house(house, req)
        self.assertFalse(result)

    def test_filter_house_subway_too_far(self):
        house = House(
            id="test123",
            address="测试地址",
            district="海淀",
            community="测试小区",
            house_type=HouseType.ENTIRE,
            layout="2室1厅1卫",
            area=80.0,
            price=5000,
            available_date="2024-01-01",
            floor="10/20",
            subway_station="测试地铁站",
            subway_distance=1500,
            xierqi_commute=25,
            decoration=Decoration.FINE,
            orientation=Orientation.SOUTH,
            bathrooms=1,
            noise_level=NoiseLevel.QUIET,
            tags=[],
            status="可租",
            latitude=39.9,
            longitude=116.3,
        )

        req = UserRequirement(max_subway_distance=800)
        result = self.agent._filter_house(house, req)
        self.assertFalse(result)


class TestIntegration(unittest.TestCase):
    def test_full_flow(self):
        agent = RentalAgent()

        query = "海淀区整租，预算5k以内，近地铁"

        try:
            result = agent.process_query(query)

            self.assertIn("requirement", result)
            self.assertIn("total_houses_found", result)
            self.assertIn("recommendations", result)

            req = result["requirement"]
            self.assertIn("max_price", req)
            self.assertEqual(req["max_price"], 5000)
            self.assertIn("districts", req)
            self.assertIn("海淀", req["districts"])

        except Exception as e:
            self.skipTest(f"API不可用: {e}")


if __name__ == "__main__":
    unittest.main()
